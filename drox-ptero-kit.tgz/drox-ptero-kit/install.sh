#!/usr/bin/env bash
# Drox Pterodactyl Kit — installs Panel + Wings + backups (every 10 min) + 2 Discord bots
# Built for IPv6-only VPS (uses DNS64/NAT64 so GitHub/Docker/etc. still work).
#
#   sudo bash install.sh                      # interactive
#   sudo PANEL_FQDN=panel.example.com NODE_FQDN=node.example.com CF_TUNNEL_TOKEN=xxxx \
#        ADMIN_EMAIL=me@example.com NONINTERACTIVE=1 bash install.sh
#
# MODE=tunnel (default): Cloudflare Tunnel exposes panel + wings over HTTPS (works with zero IPv4/IPv6 inbound).
# MODE=direct          : nginx + Let's Encrypt on the VPS's IPv6 address (needs AAAA records, clients need IPv6).
set -Eeuo pipefail
trap 'echo "✗ failed at line $LINENO (see above)"' ERR

KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STATE=/etc/drox; PANEL_DIR=/var/www/pterodactyl; BOTS=/opt/drox/bots
export DEBIAN_FRONTEND=noninteractive

c() { printf '\033[1;36m==> %s\033[0m\n' "$*"; }
w() { printf '\033[1;33m!!  %s\033[0m\n' "$*"; }
[ "$(id -u)" -eq 0 ] || { echo "run as root"; exit 1; }
. /etc/os-release
case "$ID-$VERSION_ID" in ubuntu-22.04|ubuntu-24.04|debian-12|debian-13) ;; *) w "untested OS ($PRETTY_NAME) — continuing anyway" ;; esac
ARCH=$(uname -m); case "$ARCH" in x86_64) WARCH=amd64;; aarch64) WARCH=arm64;; *) echo "unsupported arch $ARCH"; exit 1;; esac

ask() { # ask VAR "prompt" [default] [secret]
  local var="$1" prompt="$2" def="${3:-}" secret="${4:-}" val
  if [ -n "${!var:-}" ]; then return; fi
  if [ "${NONINTERACTIVE:-0}" = 1 ] || [ ! -t 0 ]; then printf -v "$var" '%s' "$def"; return; fi
  if [ -n "$secret" ]; then read -r -s -p "$prompt${def:+ [$def]}: " val; echo; else read -r -p "$prompt${def:+ [$def]}: " val; fi
  printf -v "$var" '%s' "${val:-$def}"
}
rand() { head -c 96 /dev/urandom | base64 -w0 | tr -dc A-Za-z0-9 | cut -c1-"${1:-24}"; }

mkdir -p "$STATE"; chmod 700 "$STATE"
[ -f "$STATE/kit.env" ] && . "$STATE/kit.env"     # re-runs reuse earlier answers

ask MODE          "Exposure mode (tunnel/direct)" "${MODE:-tunnel}"
ask PANEL_FQDN    "Panel domain (e.g. panel.example.com)" ""
ask NODE_FQDN     "Wings/node domain (e.g. node.example.com)" ""
ask ADMIN_EMAIL   "Admin e-mail" ""
ask ADMIN_USER    "Admin username" "admin"
ask TZ_NAME       "Timezone" "$(cat /etc/timezone 2>/dev/null || echo UTC)"
[ "$MODE" = tunnel ] && ask CF_TUNNEL_TOKEN "Cloudflare Tunnel token (blank = set up later)" "" secret
ask SETUP_BOTS    "Install the two Discord bots? (y/n)" "y"
[ -n "$PANEL_FQDN" ] && [ -n "$NODE_FQDN" ] && [ -n "$ADMIN_EMAIL" ] || { echo "PANEL_FQDN, NODE_FQDN and ADMIN_EMAIL are required"; exit 1; }
[ -f "$STATE/secrets.env" ] && . "$STATE/secrets.env"     # reruns keep the same passwords
ADMIN_PASS="${ADMIN_PASS:-$(rand 20)}"
DB_PASS="${DB_PASS:-$(rand 32)}"
printf 'ADMIN_PASS=%s\nDB_PASS=%s\n' "$ADMIN_PASS" "$DB_PASS" > "$STATE/secrets.env"; chmod 600 "$STATE/secrets.env"
cat > "$STATE/kit.env" <<KITEOF
MODE=$MODE
PANEL_FQDN=$PANEL_FQDN
NODE_FQDN=$NODE_FQDN
ADMIN_EMAIL=$ADMIN_EMAIL
ADMIN_USER=$ADMIN_USER
TZ_NAME=$TZ_NAME
KITEOF
chmod 600 "$STATE/kit.env"

# ---------------------------------------------------------------- 1. network (IPv6-only handling)
c "Checking connectivity"
HAS_V4=0; curl -4 -fsS --max-time 6 -o /dev/null https://api.ipify.org 2>/dev/null && HAS_V4=1 || true
if [ "$HAS_V4" = 0 ]; then
  w "No IPv4 detected → enabling DNS64/NAT64 resolvers so IPv4-only hosts (GitHub, Docker Hub, npm…) are reachable"
  mkdir -p /etc/systemd/resolved.conf.d
  cat > /etc/systemd/resolved.conf.d/drox-dns64.conf <<'EOF'
[Resolve]
DNS=2a00:1098:2b::1 2a00:1098:2c::1 2a01:4f8:c2c:123f::1 2001:67c:2960::64
FallbackDNS=2606:4700:4700::64 2001:4860:4860::6464
DNSSEC=no
EOF
  if systemctl is-active --quiet systemd-resolved 2>/dev/null; then systemctl restart systemd-resolved
  else
    cp -n /etc/resolv.conf /etc/resolv.conf.drox-bak 2>/dev/null || true
    printf 'nameserver 2a00:1098:2b::1\nnameserver 2a00:1098:2c::1\nnameserver 2a01:4f8:c2c:123f::1\n' > /etc/resolv.conf
  fi
  sleep 2
  curl -fsS --max-time 15 -o /dev/null https://github.com || { echo "github.com still unreachable over NAT64 — check your provider's IPv6 routing"; exit 1; }
  echo 'Acquire::ForceIPv4 "false";' > /etc/apt/apt.conf.d/99drox-v6
else echo "IPv4 present — standard setup."; fi

# ---------------------------------------------------------------- 2. packages
c "Installing base packages"
apt-get update -y
apt-get install -y curl wget tar unzip zstd git ca-certificates gnupg lsb-release software-properties-common \
  cron ufw fail2ban redis-server mariadb-server nginx jq dnsutils rsync
systemctl enable --now redis-server mariadb nginx cron

c "Installing PHP"
if   apt-cache show php8.3-fpm >/dev/null 2>&1; then PHPV=8.3
elif apt-cache show php8.2-fpm >/dev/null 2>&1; then PHPV=8.2
else
  if [ "$ID" = ubuntu ]; then add-apt-repository -y ppa:ondrej/php
  else curl -fsSL https://packages.sury.org/php/apt.gpg -o /usr/share/keyrings/sury.gpg
       echo "deb [signed-by=/usr/share/keyrings/sury.gpg] https://packages.sury.org/php/ $VERSION_CODENAME main" > /etc/apt/sources.list.d/sury.list; fi
  apt-get update -y; PHPV=8.3
fi
apt-get install -y "php$PHPV" "php$PHPV-"{cli,fpm,common,gd,mysql,mbstring,bcmath,xml,curl,zip,intl,redis}
systemctl enable --now "php$PHPV-fpm"

if [ ! -s /usr/local/bin/composer ]; then
  curl -fsSL https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
fi
chmod +x /usr/local/bin/composer
COMPOSER="php /usr/local/bin/composer"

# ---------------------------------------------------------------- 3. database
c "Configuring MariaDB"
mariadb <<SQL
CREATE USER IF NOT EXISTS 'pterodactyl'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
ALTER USER 'pterodactyl'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
CREATE DATABASE IF NOT EXISTS panel;
GRANT ALL PRIVILEGES ON panel.* TO 'pterodactyl'@'127.0.0.1' WITH GRANT OPTION;
FLUSH PRIVILEGES;
SQL

# ---------------------------------------------------------------- 4. panel
c "Installing Pterodactyl Panel"
mkdir -p "$PANEL_DIR"; cd "$PANEL_DIR"
if [ ! -f "$STATE/panel.done" ]; then
  curl -fL https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz | tar -xz
  chmod -R 755 storage/* bootstrap/cache/
  cp .env.example .env
  COMPOSER_ALLOW_SUPERUSER=1 $COMPOSER install --no-dev --optimize-autoloader --no-interaction
  php artisan key:generate --force
  PROTO=https
  php artisan p:environment:setup --author="$ADMIN_EMAIL" --url="$PROTO://$PANEL_FQDN" --timezone="$TZ_NAME" \
     --cache=redis --session=redis --queue=redis --redis-host=127.0.0.1 --redis-pass= --redis-port=6379 \
     --settings-ui=true --telemetry=false -n
  php artisan p:environment:database --host=127.0.0.1 --port=3306 --database=panel --username=pterodactyl --password="$DB_PASS" -n
  php artisan migrate --seed --force
  [ "$(mariadb -N -e 'select count(*) from panel.users')" -gt 0 ] || \
  php artisan p:user:make --email="$ADMIN_EMAIL" --username="$ADMIN_USER" --name-first=Admin --name-last=User \
     --password="$ADMIN_PASS" --admin=1 -n
  touch "$STATE/panel.done"
fi
grep -q '^TRUSTED_PROXIES=' .env || echo 'TRUSTED_PROXIES=127.0.0.1,::1' >> .env
chown -R www-data:www-data "$PANEL_DIR"
{ crontab -l 2>/dev/null | grep -v 'artisan schedule:run' || true; echo "* * * * * php $PANEL_DIR/artisan schedule:run >> /dev/null 2>&1"; } | crontab -

cat > /etc/systemd/system/pteroq.service <<EOF
[Unit]
Description=Pterodactyl Queue Worker
After=redis-server.service

[Service]
User=www-data
Group=www-data
Restart=always
ExecStart=/usr/bin/php $PANEL_DIR/artisan queue:work --queue=high,standard,low --sleep=3 --tries=3
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload; systemctl enable --now pteroq

# ---------------------------------------------------------------- 5. nginx
c "Configuring nginx ($MODE mode)"
rm -f /etc/nginx/sites-enabled/default
cat > /etc/nginx/sites-available/pterodactyl.conf <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name $PANEL_FQDN;
    root $PANEL_DIR/public;
    index index.html index.htm index.php;
    charset utf-8;
    client_max_body_size 100m;
    client_body_timeout 120s;
    sendfile off;
    access_log off;
    error_log /var/log/nginx/pterodactyl.app-error.log error;
    location / { try_files \$uri \$uri/ /index.php?\$query_string; }
    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }
    location ~ \.php\$ {
        fastcgi_split_path_info ^(.+\.php)(/.+)\$;
        fastcgi_pass unix:/run/php/php$PHPV-fpm.sock;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param PHP_VALUE "upload_max_filesize = 100M \n post_max_size=100M";
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param HTTP_PROXY "";
        fastcgi_param HTTPS \$http_x_forwarded_proto_https;
        fastcgi_intercept_errors off;
        fastcgi_buffer_size 16k;
        fastcgi_buffers 4 16k;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_read_timeout 300;
    }
    location ~ /\.ht { deny all; }
}
EOF
# map so PHP knows it's HTTPS when behind Cloudflare
cat > /etc/nginx/conf.d/drox-proto.conf <<'EOF'
map $http_x_forwarded_proto $http_x_forwarded_proto_https { default off; https on; }
EOF
ln -sf /etc/nginx/sites-available/pterodactyl.conf /etc/nginx/sites-enabled/pterodactyl.conf
nginx -t && systemctl reload nginx

if [ "$MODE" = direct ]; then
  apt-get install -y certbot python3-certbot-nginx
  certbot --nginx -d "$PANEL_FQDN" --non-interactive --agree-tos -m "$ADMIN_EMAIL" || w "certbot failed — is the AAAA record for $PANEL_FQDN pointing at this VPS?"
fi

# ---------------------------------------------------------------- 6. docker + wings
c "Installing Docker"
command -v docker >/dev/null || curl -fsSL https://get.docker.com | sh
VIRT=$(systemd-detect-virt 2>/dev/null || true)
case "$VIRT" in lxc*|openvz) w "Running inside $VIRT — Docker needs 'nesting' enabled by your provider; if docker fails to start, ask them to enable it." ;; esac
V6=0; ip -6 route show default 2>/dev/null | grep -q . && V6=1
DNS_JSON='"1.1.1.1", "8.8.8.8"'; [ "$HAS_V4" = 0 ] && DNS_JSON='"2a00:1098:2b::1", "2a00:1098:2c::1"'
mkdir -p /etc/docker
{
  echo '{'
  echo "  \"dns\": [$DNS_JSON],"
  if [ "$V6" = 1 ]; then echo '  "ipv6": true, "fixed-cidr-v6": "fd00:d0c::/64", "ip6tables": true, "experimental": true,'; fi
  echo '  "log-driver": "json-file", "log-opts": { "max-size": "10m", "max-file": "3" }'
  echo '}'
} > /etc/docker/daemon.json
systemctl enable docker && systemctl restart docker || { w "docker failed to start — see: journalctl -u docker -n 30"; exit 1; }

c "Installing Wings"
mkdir -p /etc/pterodactyl /var/lib/pterodactyl/volumes
curl -fL -o /usr/local/bin/wings "https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_$WARCH"
chmod +x /usr/local/bin/wings
cat > /etc/systemd/system/wings.service <<'EOF'
[Unit]
Description=Pterodactyl Wings Daemon
After=docker.service
Requires=docker.service
PartOf=docker.service

[Service]
User=root
WorkingDirectory=/etc/pterodactyl
LimitNOFILE=4096
PIDFile=/var/run/wings/daemon.pid
ExecStart=/usr/local/bin/wings
Restart=on-failure
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload; systemctl enable wings

# create location + node in the panel, then pull its config
c "Creating location + node in the panel"
cd "$PANEL_DIR"
MEM=$(awk '/MemTotal/{printf "%d", $2/1024}' /proc/meminfo)
DISK=$(df -BM --output=avail /var/lib | tail -1 | tr -dc 0-9)
[ "$(mariadb -N -e 'select count(*) from panel.locations')" -gt 0 ] || php artisan p:location:make --short=main --long="Main" -n
LOC_ID=$(mariadb -N -e 'select id from panel.locations order by id limit 1')
if [ "$(mariadb -N -e 'select count(*) from panel.nodes')" = 0 ]; then
  if [ "$MODE" = tunnel ]; then NSCHEME=https; NPORT=443; NPROXY=1; else NSCHEME=https; NPORT=8080; NPROXY=0; fi
  php artisan p:node:make --name="Node-1" --description="Local node" --locationId="$LOC_ID" --fqdn="$NODE_FQDN" \
     --public=1 --scheme="$NSCHEME" --proxy="$NPROXY" --maintenance=0 --maxMemory="$MEM" --overallocateMemory=0 \
     --maxDisk="$DISK" --overallocateDisk=0 --uploadSize=100 --daemonListeningPort="$NPORT" --daemonSFTPPort=2022 \
     --daemonBase=/var/lib/pterodactyl/volumes -n \
  || w "p:node:make failed (usually: $NODE_FQDN doesn't resolve yet). Create the node in the panel UI later, then run: php artisan p:node:configuration <id> > /etc/pterodactyl/config.yml"
fi
NODE_ID=$(mariadb -N -e 'select id from panel.nodes order by id limit 1' || true)
if [ -n "$NODE_ID" ]; then
  php artisan p:node:configuration "$NODE_ID" > /etc/pterodactyl/config.yml
  if [ "$MODE" = tunnel ]; then   # wings speaks plain HTTP on :8080, Cloudflare terminates TLS
    sed -i -e '/^api:/,/^system:/{s/^\(\s*port:\s*\).*/\18080/}' /etc/pterodactyl/config.yml
    python3 - <<'PY'
import re
p='/etc/pterodactyl/config.yml'; s=open(p).read()
s=re.sub(r'(ssl:\s*\n\s*enabled:\s*)true', r'\1false', s)
s=s.replace('host: 0.0.0.0','host: 0.0.0.0')
open(p,'w').write(s)
PY
  fi
  # NAT64-friendly: keep wings' own docker network with IPv6 + masquerade
  systemctl restart wings || w "wings failed to start — check: journalctl -u wings -n 50"
fi

# ---------------------------------------------------------------- 7. cloudflared
if [ "$MODE" = tunnel ]; then
  c "Installing cloudflared"
  curl -fL -o /tmp/cloudflared.deb "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-$WARCH.deb"
  dpkg -i /tmp/cloudflared.deb
  if [ -n "${CF_TUNNEL_TOKEN:-}" ]; then
    cloudflared service uninstall >/dev/null 2>&1 || true
    cloudflared service install "$CF_TUNNEL_TOKEN"
  else w "No tunnel token — later run:  cloudflared service install <TOKEN>"; fi
  cat <<EOF

  In Cloudflare Zero Trust → Tunnels → your tunnel → Public Hostnames add:
     $PANEL_FQDN  →  HTTP  localhost:80
     $NODE_FQDN   →  HTTP  localhost:8080     (also enable WebSockets — on by default)
EOF
fi

# ---------------------------------------------------------------- 8. firewall
c "Firewall (ufw)"
ufw allow OpenSSH >/dev/null || ufw allow 22/tcp >/dev/null
[ "$MODE" = direct ] && { ufw allow 80/tcp; ufw allow 443/tcp; ufw allow 8080/tcp; } >/dev/null
ufw allow 2022/tcp >/dev/null          # SFTP
ufw allow 25565:25600/tcp >/dev/null   # example game range (edit to taste)
ufw allow 25565:25600/udp >/dev/null
yes | ufw enable >/dev/null || true
systemctl enable --now fail2ban || w "fail2ban could not start (ok inside containers)"

# ---------------------------------------------------------------- 9. backups
c "Installing backup system (every 10 minutes)"
install -m 755 "$KIT/drox-backup" /usr/local/bin/drox-backup
cat > "$STATE/backup.env" <<EOF
BACKUP_DIR=/var/backups/drox
PANEL_DIR=$PANEL_DIR
BOTS_DIR=$BOTS
INCLUDE_VOLUMES=0
RCLONE_REMOTE=
EOF
cat > /etc/systemd/system/drox-backup.service <<'EOF'
[Unit]
Description=Drox panel backup
[Service]
Type=oneshot
Nice=10
IOSchedulingClass=idle
ExecStart=/usr/local/bin/drox-backup auto
EOF
cat > /etc/systemd/system/drox-backup.timer <<'EOF'
[Unit]
Description=Run Drox backup every 10 minutes
[Timer]
OnBootSec=2min
OnUnitActiveSec=10min
AccuracySec=15s
Persistent=true
[Install]
WantedBy=timers.target
EOF
systemctl daemon-reload; systemctl enable --now drox-backup.timer
/usr/local/bin/drox-backup backup first-install || w "first backup failed"

# ---------------------------------------------------------------- 10. bots
if [[ "${SETUP_BOTS,,}" == y* ]] && [ -d "$KIT/bots" ]; then
  c "Installing Node.js 22 + bots"
  if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 18 ]; then
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
    apt-get install -y nodejs
  fi
  mkdir -p "$BOTS"; rsync -a --exclude node_modules --exclude .env "$KIT/bots/" "$BOTS/"
  for b in vps-manager server-creator; do
    ( cd "$BOTS/$b" && npm install --omit=dev --no-audit --no-fund )
    [ -f "$BOTS/$b/.env" ] || cp "$BOTS/$b/.env.example" "$BOTS/$b/.env"
    chmod 600 "$BOTS/$b/.env"
    cat > "/etc/systemd/system/drox-$b.service" <<EOF
[Unit]
Description=Drox $b Discord bot
After=network-online.target
Wants=network-online.target
[Service]
WorkingDirectory=$BOTS/$b
ExecStart=/usr/bin/node index.js
Restart=always
RestartSec=5
User=root
[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload; systemctl enable "drox-$b"
  done
  sed -i "s|^PANEL_URL=.*|PANEL_URL=https://$PANEL_FQDN|" "$BOTS/server-creator/.env"
  sed -i "s|^PANEL_DIR=.*|PANEL_DIR=$PANEL_DIR|" "$BOTS/vps-manager/.env"
  cat <<EOF

  Bots installed but NOT started (they need tokens). Edit and start:
     nano $BOTS/vps-manager/.env      && systemctl start drox-vps-manager
     nano $BOTS/server-creator/.env   && systemctl start drox-server-creator
EOF
fi

# ---------------------------------------------------------------- done
cat > "$STATE/kit.env" <<EOF
MODE=$MODE
PANEL_FQDN=$PANEL_FQDN
NODE_FQDN=$NODE_FQDN
ADMIN_EMAIL=$ADMIN_EMAIL
ADMIN_USER=$ADMIN_USER
TZ_NAME=$TZ_NAME
EOF
chmod 600 "$STATE/kit.env"
cat > "$STATE/credentials.txt" <<EOF
Panel URL : https://$PANEL_FQDN
Admin user: $ADMIN_USER
Admin mail: $ADMIN_EMAIL
Admin pass: $ADMIN_PASS
DB pass   : $DB_PASS
EOF
chmod 600 "$STATE/credentials.txt"

c "DONE"
cat "$STATE/credentials.txt"
echo "(saved to $STATE/credentials.txt — change the admin password after first login)"
echo
echo "Backups : drox-backup backup | list | restore latest | timer status   (auto every 10 min → /var/backups/drox)"
echo "Reminder: IPv6-only VPS → game servers are reachable over IPv6 only. For IPv4 players use a tunnel/proxy (e.g. playit.gg)."
