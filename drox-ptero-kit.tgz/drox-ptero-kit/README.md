# Drox Pterodactyl Kit

Panel + Wings installer for **IPv6-only VPS**, auto-backups every 10 min, and two Discord bots.

## Install (one line, as root)
```bash
tar xzf drox-ptero-kit.tgz && cd drox-ptero-kit && bash install.sh
```
Non-interactive:
```bash
PANEL_FQDN=panel.example.com NODE_FQDN=node.example.com ADMIN_EMAIL=you@example.com \
CF_TUNNEL_TOKEN=xxxx NONINTERACTIVE=1 bash install.sh
```
* `MODE=tunnel` (default) → Cloudflare Tunnel. In the dashboard add hostnames:
  `panel.example.com → http://localhost:80`, `node.example.com → http://localhost:8080`.
* `MODE=direct` → nginx + Let's Encrypt on the VPS IPv6 (needs AAAA records).
* No IPv4 detected → DNS64/NAT64 resolvers are enabled automatically so GitHub/Docker/npm work.

## Backups (`drox-backup`)
| Command | What |
|---|---|
| `drox-backup backup [label]` | full backup now (DB dump + panel + /etc configs + cloudflared + bots) |
| `drox-backup list` / `latest` | show backups |
| `drox-backup restore <file\|latest>` | restore (takes a safety backup first) |
| `drox-backup verify <file>` | checksum + archive test |
| `drox-backup timer on\|off\|status` | the every-10-minutes timer |

Retention: everything for 6 h → hourly for 48 h → daily for 14 days. `*-manual*` / `*-keep*` backups are never pruned.
Config: `/etc/drox/backup.env` (`INCLUDE_VOLUMES=1` adds game-server data, `RCLONE_REMOTE=` for off-site copies).
**Off-site copy matters** — backups on the same VPS die with the VPS. Set `RCLONE_REMOTE` (e.g. `gdrive:drox`).

## Bots (in `/opt/drox/bots`)
Edit `.env`, then `systemctl start drox-vps-manager` / `drox-server-creator`.

* **vps-manager** — 88 owner-only commands: system, services, panel, wings, nginx, db, docker, tunnel, backups. Dangerous ones ask to confirm. Alerts you when a service dies or a backup is stale.
* **server-creator** — 63 commands.
  Owner: `/stopall /startall /makeserver /manage <user> /suspend /unsuspend` + 27 more.
  Users: `/manage` (list yours → buttons), `/manage <server>`, `/adduser <user> <server>` + 28 more.
  Needs a panel **Application API key** (`ptla_`) and an admin **Client API key** (`ptlc_`) in `.env`.

## IPv6-only reality check
Game servers are reachable **over IPv6 only**; IPv4-only players need a tunnel/proxy (e.g. playit.gg).
`/allocate` defaults to bind IP `::` (`ALLOC_IP`).
