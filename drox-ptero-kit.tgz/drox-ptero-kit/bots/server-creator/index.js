'use strict';
/**
 * Drox Server Creator — create & manage Pterodactyl servers from Discord.
 *
 * OWNER:  /stopall /startall /restartall /killall /makeserver /manage <user> /suspend /unsuspend /deleteserver …
 * USER:   /manage  (lists your servers → buttons)  /manage <server>  /adduser <user> <server> …
 */
require('dotenv').config();
const fs = require('fs');
const crypto = require('crypto');
const {
  Client, Events, GatewayIntentBits, REST, Routes, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder,
  ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags,
} = require('discord.js');

// ───────────────────────────── config ─────────────────────────────
const E = process.env;
const OWNERS = (E.OWNER_IDS || '').split(',').map((s) => s.trim()).filter(Boolean);
const PANEL_URL = (E.PANEL_URL || '').replace(/\/+$/, '');
const APP_KEY = E.PTERO_APP_KEY, CLIENT_KEY = E.PTERO_CLIENT_KEY;
const DEF = {
  node: parseInt(E.DEFAULT_NODE_ID || '1', 10), memory: parseInt(E.DEFAULT_MEMORY || '1024', 10),
  disk: parseInt(E.DEFAULT_DISK || '5120', 10), cpu: parseInt(E.DEFAULT_CPU || '100', 10),
  maxServers: parseInt(E.USER_DEFAULT_MAX_SERVERS || '2', 10), allocIp: E.ALLOC_IP || '::',
};
const DATA_FILE = E.DATA_FILE || './data.json';
const COUNT_ONLY = process.argv.includes('--count');
if (!COUNT_ONLY) {
  if (!E.DISCORD_TOKEN || !E.CLIENT_ID) { console.error('Set DISCORD_TOKEN and CLIENT_ID'); process.exit(1); }
  if (!OWNERS.length) { console.error('Set OWNER_IDS'); process.exit(1); }
  if (!PANEL_URL || !APP_KEY || !CLIENT_KEY) console.warn('⚠ PANEL_URL / PTERO_APP_KEY / PTERO_CLIENT_KEY missing — panel commands will fail until set.');
}
const isOwner = (id) => OWNERS.includes(id);

// ───────────────────────────── persistent data ─────────────────────────────
let db = { links: {}, shares: {}, quotas: {}, audit: [], maintenance: false };
try { db = { ...db, ...JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) }; } catch { /* first run */ }
let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => { try { fs.writeFileSync(`${DATA_FILE}.tmp`, JSON.stringify(db, null, 2)); fs.renameSync(`${DATA_FILE}.tmp`, DATA_FILE); } catch (e) { console.error('save failed', e.message); } }, 300);
}
function audit(by, action, detail = '') { db.audit.push({ t: Date.now(), by, action, detail: String(detail).slice(0, 200) }); if (db.audit.length > 500) db.audit.splice(0, db.audit.length - 500); save(); }

// ───────────────────────────── Pterodactyl API ─────────────────────────────
async function api(kind, method, p, body) {
  const base = kind === 'app' ? '/api/application' : '/api/client';
  const r = await fetch(`${PANEL_URL}${base}${p}`, {
    method, signal: AbortSignal.timeout(25000),
    headers: { Authorization: `Bearer ${kind === 'app' ? APP_KEY : CLIENT_KEY}`, Accept: 'Application/vnd.pterodactyl.v1+json', 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (r.status === 204) return null;
  const j = await r.json().catch(() => null);
  if (!r.ok) throw new Error(j?.errors?.map((e) => e.detail).join('; ') || `panel returned HTTP ${r.status}`);
  return j;
}
const app = (m, p, b) => api('app', m, p, b);
const cli = (m, p, b) => api('client', m, p, b);
async function listAll(kind, p) {
  const out = []; let page = 1, total = 1;
  const sep = p.includes('?') ? '&' : '?';
  do {
    const j = await api(kind, 'GET', `${p}${sep}per_page=100&page=${page}`);
    out.push(...j.data.map((d) => d.attributes ? { ...d.attributes, _rel: d.attributes.relationships } : d));
    total = j.meta?.pagination?.total_pages || 1; page++;
  } while (page <= total);
  return out;
}
async function getServer(ref) {
  ref = String(ref || '').trim(); if (!ref) throw new Error('no server given');
  if (/^\d+$/.test(ref)) return (await app('GET', `/servers/${ref}`)).attributes;
  let j = await app('GET', `/servers?filter[uuidShort]=${encodeURIComponent(ref)}`);
  if (!j.data.length) j = await app('GET', `/servers?filter[name]=${encodeURIComponent(ref)}`);
  if (!j.data.length) throw new Error(`server "${ref}" not found`);
  return j.data[0].attributes;
}
const power = (srv, signal) => cli('POST', `/servers/${srv.identifier}/power`, { signal });
const resources = async (srv) => { try { return (await cli('GET', `/servers/${srv.identifier}/resources`)).attributes; } catch { return null; } };

// short-lived caches (autocomplete)
const cache = { servers: { t: 0, v: [] }, eggs: { t: 0, v: [] } };
async function cachedServers() { if (Date.now() - cache.servers.t > 30000) { cache.servers = { t: Date.now(), v: await listAll('app', '/servers') }; } return cache.servers.v; }
async function cachedEggs() {
  if (Date.now() - cache.eggs.t > 300000 || !cache.eggs.v.length) {
    const nests = await app('GET', '/nests?include=eggs');
    const v = [];
    for (const n of nests.data) for (const e of n.attributes.relationships.eggs.data) v.push({ nest: n.attributes.id, nestName: n.attributes.name, id: e.attributes.id, name: e.attributes.name });
    cache.eggs = { t: Date.now(), v };
  }
  return cache.eggs.v;
}

// ───────────────────────────── access control ─────────────────────────────
const linkOf = (did) => db.links[did];
const ownsServer = (did, srv) => isOwner(did) || linkOf(did)?.panelId === srv.user;
const canAccess = (did, srv) => ownsServer(did, srv) || (db.shares[srv.identifier] || []).includes(did);
function assertAccess(i, srv, ownerOnly = false) {
  if (!(ownerOnly ? ownsServer(i.user.id, srv) : canAccess(i.user.id, srv))) throw new Error(ownerOnly ? 'Only the server owner can do that.' : 'You do not have access to that server.');
}
async function serversFor(did) {
  if (isOwner(did) && !linkOf(did)) return cachedServers();
  const out = [];
  const l = linkOf(did);
  if (l) { const u = await app('GET', `/users/${l.panelId}?include=servers`); for (const s of u.attributes.relationships.servers.data) out.push(s.attributes); }
  for (const [ident, ids] of Object.entries(db.shares)) {
    if (ids.includes(did) && !out.find((s) => s.identifier === ident)) { try { out.push(await getServer(ident)); } catch { /* deleted */ } }
  }
  return out;
}
const sharedList = (srv) => db.shares[srv.identifier] || [];

// ───────────────────────────── formatting ─────────────────────────────
const stateIcon = (s) => ({ running: '🟢', starting: '🟡', stopping: '🟠', offline: '🔴' }[s] || '⚪');
const mb = (b) => `${(b / 1048576).toFixed(0)} MB`;
const lim = (n, unit) => (n === 0 ? '∞' : `${n}${unit}`);
const clip = (s, n = 1000) => (String(s).length > n ? `${String(s).slice(0, n - 1)}…` : String(s));
const rand = (n = 16) => crypto.randomBytes(n).toString('base64').replace(/[^A-Za-z0-9]/g, '').slice(0, n);
const hostPort = (ip, port) => (ip.includes(':') ? `[${ip}]:${port}` : `${ip}:${port}`);

async function serverEmbed(srv) {
  const r = await resources(srv);
  const state = srv.suspended ? 'suspended' : (r?.current_state || 'unknown');
  const e = new EmbedBuilder().setTitle(`${srv.suspended ? '⛔' : stateIcon(state)} ${srv.name}`)
    .setColor(srv.suspended ? 0x95a5a6 : state === 'running' ? 0x2ecc71 : state === 'offline' ? 0xe74c3c : 0xf1c40f)
    .setDescription(`ID \`${srv.identifier}\` · #${srv.id} · state **${state}**`)
    .addFields(
      { name: 'Memory', value: `${r ? mb(r.resources.memory_bytes) : '–'} / ${lim(srv.limits.memory, ' MB')}`, inline: true },
      { name: 'CPU', value: `${r ? r.resources.cpu_absolute.toFixed(1) : '–'}% / ${lim(srv.limits.cpu, '%')}`, inline: true },
      { name: 'Disk', value: `${r ? mb(r.resources.disk_bytes) : '–'} / ${lim(srv.limits.disk, ' MB')}`, inline: true },
    ).setTimestamp();
  const sh = sharedList(srv); if (sh.length) e.addFields({ name: 'Shared with', value: sh.map((d) => `<@${d}>`).join(' ') });
  return e;
}
function serverRows(srv) {
  const id = srv.identifier;
  const b = (a, label, style) => new ButtonBuilder().setCustomId(`mg|${a}|${id}`).setLabel(label).setStyle(style);
  return [
    new ActionRowBuilder().addComponents(b('start', '▶ Start', ButtonStyle.Success), b('restart', '🔄 Restart', ButtonStyle.Primary), b('stop', '⏹ Stop', ButtonStyle.Secondary), b('kill', '☠ Kill', ButtonStyle.Danger)),
    new ActionRowBuilder().addComponents(b('refresh', '↻ Refresh', ButtonStyle.Secondary), b('console', '⌨ Command', ButtonStyle.Secondary), b('backup', '💾 Backup', ButtonStyle.Secondary), b('address', '🌐 Address', ButtonStyle.Secondary)),
  ];
}
const managePayload = async (srv) => ({ content: '', embeds: [await serverEmbed(srv)], components: serverRows(srv) });
function serverSelect(servers, placeholder = 'Pick a server to manage') {
  return new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('mgsel').setPlaceholder(placeholder)
    .addOptions(servers.slice(0, 25).map((s) => ({ label: clip(s.name, 100), description: `${s.identifier} · ${s.limits.memory}MB`, value: s.identifier }))));
}
const lines = (arr, max = 3900) => clip(arr.join('\n'), max);

// ───────────────────────────── command registry ─────────────────────────────
const defs = [];
const str = (name, desc, required = true, x = {}) => ({ type: 'string', name, desc, required, ...x });
const int = (name, desc, required = false, x = {}) => ({ type: 'integer', name, desc, required, ...x });
const usr = (name, desc, required = true) => ({ type: 'user', name, desc, required });
const bool = (name, desc, required = false) => ({ type: 'boolean', name, desc, required });
const serverOpt = (desc = 'server (pick from list)', required = true) => str('server', desc, required, { auto: 'server' });
/** cmd(name, desc, scope 'owner'|'user', options, run, meta) */
function cmd(name, desc, scope, options, run, meta = {}) { defs.push({ name, desc, scope, options: options || [], run, ...meta }); }

/** resolve option 'server' + check access */
async function srvOf(i, ownerOnly = false) {
  const srv = await getServer(i.options.getString('server'));
  assertAccess(i, srv, ownerOnly); return srv;
}
const emb = (title, desc, color = 0x5865f2) => ({ embeds: [new EmbedBuilder().setTitle(title).setDescription(desc || '​').setColor(color)] });
const text = (t) => ({ content: t });

// concurrency-limited bulk power
async function bulkPower(signal) {
  const all = (await listAll('app', '/servers')).filter((s) => !s.suspended && s.container?.installed !== 0);
  let ok = 0, fail = 0; const failed = [];
  const queue = [...all];
  await Promise.all(Array.from({ length: 4 }, async () => {
    while (queue.length) {
      const s = queue.shift();
      try { await power(s, signal); ok++; } catch (e) { fail++; failed.push(`${s.name}: ${clip(e.message, 60)}`); }
    }
  }));
  return { total: all.length, ok, fail, failed };
}
const bulkReply = (verb, r) => emb(`${verb} all servers`, `✅ ${r.ok} / ${r.total} signalled${r.fail ? `\n❌ ${r.fail} failed\n${lines(r.failed.slice(0, 10).map((f) => `• ${f}`), 1500)}` : ''}`, r.fail ? 0xe67e22 : 0x2ecc71);

// ═════════════════ OWNER: bulk power ═════════════════
const bulk = (name, signal, verb, dangerMsg) => cmd(name, `${verb} every server on the panel`, 'owner', [], async (i) => { audit(i.user.id, name); return bulkReply(verb, await bulkPower(signal)); }, { danger: () => dangerMsg });
bulk('stopall', 'stop', 'Stop', '⚠️ Stop **every** server?');
bulk('startall', 'start', 'Start', 'Start **every** server?');
bulk('restartall', 'restart', 'Restart', '⚠️ Restart **every** server?');
bulk('killall', 'kill', 'Kill', '☠️ Force-KILL **every** server? (data loss possible)');

// ═════════════════ OWNER: make server ═════════════════
cmd('makeserver', 'Create a server for a user', 'owner', [
  usr('user', 'owner of the new server'), str('name', 'server name'), str('egg', 'game / software', true, { auto: 'egg' }),
  int('memory', `RAM in MB (default ${DEF.memory})`, false, { min: 128, max: 262144 }),
  int('disk', `disk in MB (default ${DEF.disk})`, false, { min: 128, max: 4194304 }),
  int('cpu', `CPU % — 100 = 1 core, 0 = unlimited (default ${DEF.cpu})`, false, { min: 0, max: 6400 }),
  int('node', `node id (default ${DEF.node})`, false, { min: 1 }), bool('force', 'ignore the user\'s server quota'),
], async (i) => {
  const target = i.options.getUser('user'); const link = linkOf(target.id);
  if (!link) throw new Error(`<@${target.id}> has no panel account linked — use /createaccount or /linkuser first.`);
  const q = db.quotas[target.id] || {}; const max = q.servers ?? DEF.maxServers;
  const have = (await serversFor(target.id)).filter((s) => s.user === link.panelId).length;
  if (have >= max && !i.options.getBoolean('force')) throw new Error(`<@${target.id}> already has ${have}/${max} servers (use force:true or /quota).`);
  const [nestId, eggId] = i.options.getString('egg').split(':').map(Number);
  if (!nestId || !eggId) throw new Error('pick the egg from the autocomplete list');
  const egg = (await app('GET', `/nests/${nestId}/eggs/${eggId}?include=variables`)).attributes;
  const environment = {}; for (const v of egg.relationships.variables.data) environment[v.attributes.env_variable] = v.attributes.default_value ?? '';
  const nodeId = i.options.getInteger('node') || DEF.node;
  const allocs = await listAll('app', `/nodes/${nodeId}/allocations`);
  const free = allocs.find((a) => !a.assigned);
  if (!free) throw new Error(`No free allocation on node ${nodeId} — run /allocate first.`);
  const memory = i.options.getInteger('memory') ?? q.memory ?? DEF.memory, disk = i.options.getInteger('disk') ?? q.disk ?? DEF.disk, cpu = i.options.getInteger('cpu') ?? DEF.cpu;
  const j = await app('POST', '/servers', {
    name: i.options.getString('name'), user: link.panelId, egg: egg.id, docker_image: egg.docker_image, startup: egg.startup, environment,
    limits: { memory, swap: 0, disk, io: 500, cpu }, feature_limits: { databases: 1, allocations: 1, backups: 2 },
    allocation: { default: free.id }, start_on_completion: true,
  });
  const s = j.attributes; cache.servers.t = 0; audit(i.user.id, 'makeserver', `${s.name} (${s.identifier}) for ${target.id}`);
  return { ...emb('✅ Server created', `**${s.name}** · \`${s.identifier}\`\nOwner: <@${target.id}>\nEgg: ${egg.name}\n${memory} MB RAM · ${disk} MB disk · ${cpu}% CPU\nAddress: \`${hostPort(free.alias || free.ip, free.port)}\`\nIt is installing now — manage it with \`/manage server:${s.identifier}\`.`, 0x2ecc71) };
});

// ═════════════════ BOTH: /manage ═════════════════
cmd('manage', 'Manage servers: list yours, or open one with its control panel', 'user', [
  serverOpt('open this server directly (ID or name)', false), usr('user', 'OWNER ONLY — show another user\'s servers', false),
], async (i) => {
  const sid = i.options.getString('server'); const who = i.options.getUser('user');
  if (who && !isOwner(i.user.id)) throw new Error('Only the owner can look at other users\' servers.');
  if (sid) { const srv = await getServer(sid); assertAccess(i, srv); return managePayload(srv); }
  const target = who || i.user;
  if (!linkOf(target.id) && !isOwner(i.user.id) && !Object.values(db.shares).some((a) => a.includes(target.id)))
    throw new Error('No panel account linked to you yet — ask the owner to run /createaccount or /linkuser.');
  const list = await serversFor(target.id);
  if (!list.length) return emb(`${who ? `${target.username}'s` : 'Your'} servers`, 'No servers.');
  const d = list.slice(0, 25).map((s) => `${s.suspended ? '⛔' : '•'} **${s.name}** — \`${s.identifier}\`${canAccess(target.id, s) && !ownsServer(target.id, s) ? ' _(shared)_' : ''}`);
  return { ...emb(`${who ? `${target.username}'s` : 'Your'} servers (${list.length})`, lines(d)), components: [serverSelect(list)] };
});

cmd('adduser', 'Give another Discord user access to manage one of your servers', 'user', [usr('user', 'who to add'), serverOpt()], async (i) => {
  const srv = await srvOf(i, true); const u = i.options.getUser('user');
  if (u.bot) throw new Error('Bots cannot manage servers.'); if (u.id === i.user.id) throw new Error('You already have access.');
  const arr = (db.shares[srv.identifier] ||= []);
  if (arr.length >= 10) throw new Error('Max 10 shared users per server.');
  if (!arr.includes(u.id)) arr.push(u.id); save(); audit(i.user.id, 'adduser', `${u.id} → ${srv.identifier}`);
  return emb('✅ Access granted', `<@${u.id}> can now manage **${srv.name}** (\`${srv.identifier}\`) with \`/manage\`.\nThey can start/stop/restart/kill, send commands and make backups.`, 0x2ecc71);
});
cmd('removeuser', 'Remove a user\'s access to one of your servers', 'user', [usr('user', 'who to remove'), serverOpt()], async (i) => {
  const srv = await srvOf(i, true); const u = i.options.getUser('user');
  db.shares[srv.identifier] = sharedList(srv).filter((d) => d !== u.id); if (!db.shares[srv.identifier].length) delete db.shares[srv.identifier];
  save(); audit(i.user.id, 'removeuser', `${u.id} ✗ ${srv.identifier}`);
  return text(`Removed <@${u.id}> from **${srv.name}**.`);
});
cmd('sharedwith', 'Who can manage a server', 'user', [serverOpt()], async (i) => {
  const srv = await srvOf(i); const l = linkOf(i.user.id);
  return emb(`Access — ${srv.name}`, `Owner account: panel user #${srv.user}\nShared: ${sharedList(srv).map((d) => `<@${d}>`).join(' ') || 'nobody'}${l ? '' : ''}`);
});

// ═════════════════ USER: myservers / info / power ═════════════════
cmd('myservers', 'List your servers with live state', 'user', [], async (i) => {
  const list = await serversFor(i.user.id); if (!list.length) return text('You have no servers.');
  const rows = await Promise.all(list.slice(0, 15).map(async (s) => { const r = await resources(s); return `${s.suspended ? '⛔' : stateIcon(r?.current_state)} **${s.name}** \`${s.identifier}\` — ${r?.current_state || 'unknown'}`; }));
  return { ...emb(`Your servers (${list.length})`, lines(rows)), components: [serverSelect(list)] };
});
cmd('serverinfo', 'Details about a server', 'user', [serverOpt()], async (i) => {
  const srv = await srvOf(i);
  return { embeds: [(await serverEmbed(srv)).addFields({ name: 'Node', value: String(srv.node), inline: true }, { name: 'Created', value: `<t:${Math.floor(new Date(srv.created_at) / 1000)}:R>`, inline: true })] };
});
cmd('status', 'Quick state of a server', 'user', [serverOpt()], async (i) => { const srv = await srvOf(i); const r = await resources(srv); return text(`${srv.suspended ? '⛔ suspended' : `${stateIcon(r?.current_state)} ${r?.current_state || 'unknown'}`} — **${srv.name}**`); });
cmd('resources', 'Live CPU / RAM / disk / network', 'user', [serverOpt()], async (i) => {
  const srv = await srvOf(i); const r = await resources(srv); if (!r) throw new Error('could not read resources (server offline or installing)');
  const x = r.resources;
  return emb(`📊 ${srv.name}`, `State: **${r.current_state}**\nCPU: ${x.cpu_absolute.toFixed(1)}%\nRAM: ${mb(x.memory_bytes)} / ${lim(srv.limits.memory, ' MB')}\nDisk: ${mb(x.disk_bytes)} / ${lim(srv.limits.disk, ' MB')}\nNet ↓ ${mb(x.network_rx_bytes)} · ↑ ${mb(x.network_tx_bytes)}\nUptime: ${Math.floor((x.uptime || 0) / 60000)} min`);
});
const pw = (name, signal, verb, dangerous) => cmd(name, `${verb} a server`, 'user', [serverOpt()], async (i) => {
  const srv = await srvOf(i); if (srv.suspended) throw new Error('This server is suspended.');
  await power(srv, signal); audit(i.user.id, name, srv.identifier); return text(`${verb} signal sent to **${srv.name}**.`);
}, dangerous ? { danger: (i) => `Force-kill **${i.options.getString('server')}**? Unsaved data may be lost.` } : {});
pw('start', 'start', 'Start'); pw('stop', 'stop', 'Stop'); pw('restart', 'restart', 'Restart'); pw('kill', 'kill', 'Kill', true);
const mine = (name, signal, verb) => cmd(name, `${verb} all of YOUR servers`, 'user', [], async (i) => {
  const list = (await serversFor(i.user.id)).filter((s) => !s.suspended && ownsServer(i.user.id, s) && !isOwner(i.user.id)); let ok = 0;
  for (const s of list) { try { await power(s, signal); ok++; } catch { /* skip */ } }
  return text(`${verb} signal sent to ${ok}/${list.length} of your servers.`);
});
mine('startmine', 'start', 'Start'); mine('stopmine', 'stop', 'Stop');
cmd('console', 'Send a command to a server console', 'user', [serverOpt(), str('command', 'command to run')], async (i) => {
  const srv = await srvOf(i); const c = i.options.getString('command');
  await cli('POST', `/servers/${srv.identifier}/command`, { command: c }); audit(i.user.id, 'console', `${srv.identifier}: ${c}`);
  return text(`Sent \`${clip(c, 200)}\` to **${srv.name}**.`);
});
cmd('address', 'Connection address of a server', 'user', [serverOpt()], async (i) => {
  const srv = await srvOf(i); const j = await cli('GET', `/servers/${srv.identifier}`);
  const a = j.attributes.relationships.allocations.data.map((d) => d.attributes);
  return emb(`🌐 ${srv.name}`, a.map((x) => `${x.is_default ? '⭐' : '•'} \`${hostPort(x.ip_alias || x.ip, x.port)}\``).join('\n') || 'no allocations');
});
cmd('rename', 'Rename a server', 'user', [serverOpt(), str('name', 'new name')], async (i) => {
  const srv = await srvOf(i, true); const n = i.options.getString('name');
  await app('PATCH', `/servers/${srv.id}/details`, { name: n, user: srv.user, description: srv.description || '' }); cache.servers.t = 0; audit(i.user.id, 'rename', `${srv.identifier} → ${n}`);
  return text(`Renamed to **${clip(n, 100)}**.`);
});
cmd('reinstall', 'Reinstall a server (wipes install files per egg script)', 'user', [serverOpt()], async (i) => {
  const srv = await srvOf(i, true); await app('POST', `/servers/${srv.id}/reinstall`); audit(i.user.id, 'reinstall', srv.identifier); return text(`Reinstall started for **${srv.name}**.`);
}, { danger: (i) => `⚠️ Reinstall **${i.options.getString('server')}**? The egg install script runs again and may overwrite files.` });

// variables / startup
cmd('variables', 'Show a server\'s startup variables', 'user', [serverOpt()], async (i) => {
  const srv = await srvOf(i); const j = await cli('GET', `/servers/${srv.identifier}/startup`);
  return emb(`⚙️ ${srv.name}`, lines(j.data.map((d) => `${d.attributes.is_editable ? '✏️' : '🔒'} \`${d.attributes.env_variable}\` = \`${clip(d.attributes.server_value, 60)}\``)));
});
cmd('setvar', 'Change an editable startup variable', 'user', [serverOpt(), str('key', 'variable name, e.g. MINECRAFT_VERSION'), str('value', 'new value')], async (i) => {
  const srv = await srvOf(i, true);
  await cli('PUT', `/servers/${srv.identifier}/startup/variable`, { key: i.options.getString('key'), value: i.options.getString('value') });
  audit(i.user.id, 'setvar', `${srv.identifier} ${i.options.getString('key')}`); return text('Variable updated. Restart the server to apply it.');
});

// files & backups
cmd('files', 'List files in a server directory', 'user', [serverOpt(), str('directory', 'path, default /', false)], async (i) => {
  const srv = await srvOf(i); const d = i.options.getString('directory') || '/';
  const j = await cli('GET', `/servers/${srv.identifier}/files/list?directory=${encodeURIComponent(d)}`);
  const rows = j.data.slice(0, 40).map((f) => `${f.attributes.is_file ? '📄' : '📁'} ${f.attributes.name}${f.attributes.is_file ? ` (${(f.attributes.size / 1024).toFixed(0)} KB)` : ''}`);
  return emb(`${srv.name}:${d}`, lines(rows) + (j.data.length > 40 ? `\n… +${j.data.length - 40} more` : ''));
});
cmd('backup-create', 'Create a server backup', 'user', [serverOpt(), str('name', 'backup name', false)], async (i) => {
  const srv = await srvOf(i); const n = i.options.getString('name');
  const j = await cli('POST', `/servers/${srv.identifier}/backups`, n ? { name: n } : {}); audit(i.user.id, 'backup-create', srv.identifier);
  return text(`💾 Backup **${j.attributes.name}** started for ${srv.name}.`);
});
cmd('backups', 'List a server\'s backups', 'user', [serverOpt()], async (i) => {
  const srv = await srvOf(i); const j = await cli('GET', `/servers/${srv.identifier}/backups`);
  return emb(`💾 ${srv.name}`, lines(j.data.map((b) => `${b.attributes.is_successful ? '✅' : '⏳'} **${clip(b.attributes.name, 40)}** — ${mb(b.attributes.bytes)} — \`${b.attributes.uuid}\``)) || 'no backups');
});
cmd('backup-delete', 'Delete a server backup', 'user', [serverOpt(), str('uuid', 'backup uuid (see /backups)')], async (i) => {
  const srv = await srvOf(i, true); await cli('DELETE', `/servers/${srv.identifier}/backups/${encodeURIComponent(i.options.getString('uuid'))}`); audit(i.user.id, 'backup-delete', srv.identifier); return text('Backup deleted.');
}, { danger: () => 'Delete this backup permanently?' });

// account / info
cmd('mylimits', 'Your server quota and usage', 'user', [], async (i) => {
  const q = db.quotas[i.user.id] || {}; const list = (await serversFor(i.user.id)).filter((s) => ownsServer(i.user.id, s));
  const mem = list.reduce((a, s) => a + s.limits.memory, 0), disk = list.reduce((a, s) => a + s.limits.disk, 0);
  return emb('Your limits', `Servers: **${list.length}** / ${q.servers ?? DEF.maxServers}\nRAM allocated: ${mem} MB${q.memory ? ` (default for new: ${q.memory} MB)` : ''}\nDisk allocated: ${disk} MB`);
});
cmd('whoami', 'Your link status', 'user', [], async (i) => { const l = linkOf(i.user.id); return text(isOwner(i.user.id) ? `👑 Owner${l ? ` · panel user #${l.panelId} (${l.email})` : ' · no panel account linked'}` : l ? `Linked to panel user #${l.panelId} (${l.email})` : 'Not linked — ask the owner for /createaccount.'); });
cmd('panel', 'Link to the panel', 'user', [], async () => text(`🔗 ${PANEL_URL}`));
cmd('eggs', 'Available server types', 'user', [], async () => { const eggs = await cachedEggs(); const by = {}; for (const e of eggs) (by[e.nestName] ||= []).push(e.name); return { embeds: [new EmbedBuilder().setTitle('Available eggs').setColor(0x5865f2).addFields(...Object.entries(by).slice(0, 25).map(([n, a]) => ({ name: n, value: clip(a.join(', '), 1000) })))] }; });
cmd('botping', 'Bot latency', 'user', [], async (i) => text(`🏓 ${i.client.ws.ping} ms`));
cmd('about', 'About this bot', 'user', [], async (i) => emb('Drox Server Creator', `Panel: ${PANEL_URL}\nCommands: **${defs.length}**\nUptime: ${Math.floor(process.uptime() / 60)} min`));

// ═════════════════ OWNER: moderation of servers ═════════════════
const svcmd = (name, path, verb) => cmd(name, `${verb} a server`, 'owner', [serverOpt()], async (i) => { const srv = await getServer(i.options.getString('server')); await app('POST', `/servers/${srv.id}/${path}`); cache.servers.t = 0; audit(i.user.id, name, srv.identifier); return text(`${verb}: **${srv.name}** (\`${srv.identifier}\`)`); });
svcmd('suspend', 'suspend', 'Suspended'); svcmd('unsuspend', 'unsuspend', 'Unsuspended');
cmd('deleteserver', 'DELETE a server permanently', 'owner', [serverOpt(), bool('force', 'force delete even if wings errors')], async (i) => {
  const srv = await getServer(i.options.getString('server')); await app('DELETE', `/servers/${srv.id}${i.options.getBoolean('force') ? '/force' : ''}`); delete db.shares[srv.identifier]; save(); cache.servers.t = 0;
  audit(i.user.id, 'deleteserver', `${srv.name} (${srv.identifier})`); return text(`🗑️ Deleted **${srv.name}**.`);
}, { danger: (i) => `🗑️ Permanently delete **${i.options.getString('server')}** and all its data?` });
cmd('resize', 'Change a server\'s limits', 'owner', [serverOpt(), int('memory', 'RAM MB', false, { min: 0 }), int('disk', 'disk MB', false, { min: 0 }), int('cpu', 'CPU %', false, { min: 0 })], async (i) => {
  const srv = await getServer(i.options.getString('server'));
  const l = { memory: i.options.getInteger('memory') ?? srv.limits.memory, disk: i.options.getInteger('disk') ?? srv.limits.disk, cpu: i.options.getInteger('cpu') ?? srv.limits.cpu };
  await app('PATCH', `/servers/${srv.id}/build`, { allocation: srv.allocation, memory: l.memory, swap: srv.limits.swap, disk: l.disk, io: srv.limits.io, cpu: l.cpu, threads: srv.limits.threads, feature_limits: srv.feature_limits });
  audit(i.user.id, 'resize', `${srv.identifier} ${JSON.stringify(l)}`); return text(`Updated **${srv.name}**: ${l.memory} MB RAM · ${l.disk} MB disk · ${l.cpu}% CPU`);
});
cmd('giveserver', 'Transfer a server to another linked user', 'owner', [serverOpt(), usr('user', 'new owner')], async (i) => {
  const srv = await getServer(i.options.getString('server')); const u = i.options.getUser('user'); const l = linkOf(u.id); if (!l) throw new Error('that user has no linked panel account');
  await app('PATCH', `/servers/${srv.id}/details`, { name: srv.name, user: l.panelId, description: srv.description || '' }); cache.servers.t = 0; audit(i.user.id, 'giveserver', `${srv.identifier} → ${u.id}`);
  return text(`**${srv.name}** now belongs to <@${u.id}>.`);
});
cmd('listservers', 'List all servers on the panel', 'owner', [int('page', 'page number', false, { min: 1 })], async (i) => {
  const all = await cachedServers(); const per = 20, pages = Math.max(1, Math.ceil(all.length / per)), p = Math.min(i.options.getInteger('page') || 1, pages);
  return emb(`Servers — page ${p}/${pages} (${all.length} total)`, lines(all.slice((p - 1) * per, p * per).map((s) => `${s.suspended ? '⛔' : '•'} **${clip(s.name, 30)}** \`${s.identifier}\` · user #${s.user} · ${s.limits.memory}MB`)) || 'none');
});
cmd('servercount', 'How many servers exist', 'owner', [], async () => { const j = await app('GET', '/servers?per_page=1'); return text(`🖥️ ${j.meta.pagination.total} servers`); });
cmd('search', 'Search servers by name / id', 'owner', [str('query', 'text')], async (i) => {
  const q = i.options.getString('query').toLowerCase(); const r = (await cachedServers()).filter((s) => `${s.name} ${s.identifier} ${s.uuid}`.toLowerCase().includes(q)).slice(0, 20);
  return emb(`Search "${clip(q, 40)}"`, lines(r.map((s) => `**${clip(s.name, 30)}** \`${s.identifier}\` · #${s.id} · user #${s.user}`)) || 'no match');
});
cmd('broadcast', 'Send a console command to EVERY running server (e.g. say Restart soon)', 'owner', [str('command', 'console command')], async (i) => {
  const all = (await listAll('app', '/servers')).filter((s) => !s.suspended); let ok = 0;
  for (const s of all) { try { await cli('POST', `/servers/${s.identifier}/command`, { command: i.options.getString('command') }); ok++; } catch { /* offline */ } }
  audit(i.user.id, 'broadcast', i.options.getString('command')); return text(`📣 Delivered to ${ok}/${all.length} servers.`);
}, { danger: (i) => `Send \`${clip(i.options.getString('command'), 200)}\` to every server?` });

// ═════════════════ OWNER: infrastructure ═════════════════
cmd('nodes', 'List nodes', 'owner', [], async () => { const n = await listAll('app', '/nodes'); return emb('Nodes', lines(n.map((x) => `**#${x.id} ${x.name}** — ${x.fqdn} — RAM ${x.allocated_resources.memory}/${x.memory} MB · disk ${x.allocated_resources.disk}/${x.disk} MB`))); });
cmd('nodeinfo', 'Details of one node', 'owner', [int('node', `node id (default ${DEF.node})`, false, { min: 1 })], async (i) => {
  const x = (await app('GET', `/nodes/${i.options.getInteger('node') || DEF.node}`)).attributes;
  return emb(`Node #${x.id} — ${x.name}`, `FQDN: ${x.fqdn}:${x.daemon_listen}\nScheme: ${x.scheme} · proxy: ${x.behind_proxy}\nRAM: ${x.allocated_resources.memory}/${x.memory} MB\nDisk: ${x.allocated_resources.disk}/${x.disk} MB\nMaintenance: ${x.maintenance_mode}`);
});
cmd('locations', 'List locations', 'owner', [], async () => { const l = await listAll('app', '/locations'); return emb('Locations', lines(l.map((x) => `#${x.id} **${x.short}** — ${x.long || ''}`)) || 'none'); });
cmd('nests', 'List nests', 'owner', [], async () => { const n = await listAll('app', '/nests'); return emb('Nests', lines(n.map((x) => `#${x.id} **${x.name}**`))); });
cmd('allocations', 'Allocations of a node', 'owner', [int('node', 'node id', false, { min: 1 }), bool('free', 'only free ones')], async (i) => {
  const a = (await listAll('app', `/nodes/${i.options.getInteger('node') || DEF.node}/allocations`)).filter((x) => !i.options.getBoolean('free') || !x.assigned);
  return emb(`Allocations (${a.length})`, lines(a.slice(0, 40).map((x) => `${x.assigned ? '🔴' : '🟢'} \`${hostPort(x.alias || x.ip, x.port)}\``)) + (a.length > 40 ? `\n… +${a.length - 40}` : ''));
});
cmd('allocate', 'Add port allocations to a node', 'owner', [int('port_start', 'first port', true, { min: 1024, max: 65535 }), int('port_end', 'last port (optional)', false, { min: 1024, max: 65535 }), int('node', 'node id', false, { min: 1 }), str('ip', `bind IP (default ${DEF.allocIp})`, false)], async (i) => {
  const s = i.options.getInteger('port_start'), e = i.options.getInteger('port_end') || s; if (e < s || e - s > 500) throw new Error('bad range (max 500 ports)');
  const ip = i.options.getString('ip') || DEF.allocIp; const node = i.options.getInteger('node') || DEF.node;
  await app('POST', `/nodes/${node}/allocations`, { ip, ports: [s === e ? String(s) : `${s}-${e}`] }); audit(i.user.id, 'allocate', `${node} ${ip} ${s}-${e}`);
  return text(`Added ${e - s + 1} allocation(s) on node ${node} (${ip}).`);
});
cmd('panelstats', 'Panel totals', 'owner', [], async () => {
  const [s, u, n] = await Promise.all(['servers', 'users', 'nodes'].map((x) => app('GET', `/${x}?per_page=1`)));
  return emb('Panel stats', `Servers: **${s.meta.pagination.total}**\nUsers: **${u.meta.pagination.total}**\nNodes: **${n.meta.pagination.total}**\nLinked Discord users: **${Object.keys(db.links).length}**`);
});
cmd('pingpanel', 'Panel API latency', 'owner', [], async () => { const t = Date.now(); await app('GET', '/nodes?per_page=1'); return text(`Panel API: ${Date.now() - t} ms`); });

// ═════════════════ OWNER: accounts ═════════════════
async function panelUserByEmail(email) { const j = await app('GET', `/users?filter[email]=${encodeURIComponent(email)}`); const u = j.data.find((d) => d.attributes.email.toLowerCase() === email.toLowerCase()); if (!u) throw new Error(`no panel user with email ${email}`); return u.attributes; }
cmd('createaccount', 'Create a panel account for a Discord user and link it', 'owner', [usr('user', 'Discord user'), str('email', 'their email'), str('username', 'panel username (default: Discord name)', false)], async (i) => {
  const u = i.options.getUser('user'); if (linkOf(u.id)) throw new Error('already linked');
  const name = (i.options.getString('username') || u.username).toLowerCase().replace(/[^a-z0-9._-]/g, '').replace(/^[^a-z0-9]+|[^a-z0-9]+$/g, '').slice(0, 30) || `user${rand(6).toLowerCase()}`;
  const pass = rand(16); const email = i.options.getString('email');
  const j = await app('POST', '/users', { email, username: name, first_name: clip(u.username, 30), last_name: 'User', password: pass });
  db.links[u.id] = { panelId: j.attributes.id, email }; save(); audit(i.user.id, 'createaccount', `${u.id} → #${j.attributes.id}`);
  let dm = true; try { await u.send(`Your panel account is ready!\n**URL:** ${PANEL_URL}\n**Email:** ${email}\n**Username:** ${name}\n**Password:** ||${pass}|| — change it after logging in.\nUse \`/manage\` in Discord to control your servers.`); } catch { dm = false; }
  return { content: `✅ Account **${name}** created and linked to <@${u.id}>.${dm ? ' Credentials sent by DM.' : ` ⚠️ Could not DM — give them this password manually: ||${pass}||`}` };
});
cmd('linkuser', 'Link a Discord user to an existing panel account', 'owner', [usr('user', 'Discord user'), str('email', 'panel account email')], async (i) => {
  const u = i.options.getUser('user'); const p = await panelUserByEmail(i.options.getString('email')); db.links[u.id] = { panelId: p.id, email: p.email }; save(); audit(i.user.id, 'linkuser', `${u.id} → #${p.id}`);
  return text(`Linked <@${u.id}> → panel user #${p.id} (${p.email}).`);
});
cmd('unlinkuser', 'Remove a Discord ↔ panel link', 'owner', [usr('user', 'Discord user')], async (i) => { const u = i.options.getUser('user'); delete db.links[u.id]; save(); audit(i.user.id, 'unlinkuser', u.id); return text(`Unlinked <@${u.id}>.`); });
cmd('users', 'List panel users', 'owner', [int('page', 'page', false, { min: 1 })], async (i) => {
  const j = await app('GET', `/users?per_page=20&page=${i.options.getInteger('page') || 1}`);
  return emb(`Panel users (${j.meta.pagination.total})`, lines(j.data.map((d) => `#${d.attributes.id} **${d.attributes.username}** — ${d.attributes.email}${d.attributes.root_admin ? ' 👑' : ''}`)));
});
cmd('userinfo', 'Info about a user (Discord mention or panel email)', 'owner', [usr('user', 'Discord user', false), str('email', 'or panel email', false)], async (i) => {
  const u = i.options.getUser('user'); const em = i.options.getString('email'); let p;
  if (em) p = await panelUserByEmail(em); else if (u && linkOf(u.id)) p = (await app('GET', `/users/${linkOf(u.id).panelId}?include=servers`)).attributes; else throw new Error('give a linked Discord user or an email');
  const sv = (await serversFor(Object.keys(db.links).find((k) => db.links[k].panelId === p.id) || '0')).filter((s) => s.user === p.id);
  const dis = Object.keys(db.links).find((k) => db.links[k].panelId === p.id);
  return emb(`👤 ${p.username}`, `Panel #${p.id} · ${p.email}\nAdmin: ${p.root_admin}\n2FA: ${p['2fa']}\nDiscord: ${dis ? `<@${dis}>` : 'not linked'}\nServers (${sv.length}): ${sv.map((s) => `\`${s.identifier}\``).join(' ') || 'none'}`);
});
cmd('resetpassword', 'Reset a linked user\'s panel password and DM it', 'owner', [usr('user', 'Discord user')], async (i) => {
  const u = i.options.getUser('user'); const l = linkOf(u.id); if (!l) throw new Error('not linked');
  const p = (await app('GET', `/users/${l.panelId}`)).attributes; const pass = rand(16);
  await app('PATCH', `/users/${l.panelId}`, { email: p.email, username: p.username, first_name: p.first_name, last_name: p.last_name, language: p.language || 'en', password: pass }); audit(i.user.id, 'resetpassword', u.id);
  let dm = true; try { await u.send(`Your panel password was reset: ||${pass}||`); } catch { dm = false; }
  return text(dm ? 'New password sent by DM.' : `Could not DM. New password: ||${pass}||`);
});
cmd('deleteaccount', 'Delete a linked user\'s panel account (must have no servers)', 'owner', [usr('user', 'Discord user')], async (i) => {
  const u = i.options.getUser('user'); const l = linkOf(u.id); if (!l) throw new Error('not linked');
  await app('DELETE', `/users/${l.panelId}`); delete db.links[u.id]; save(); audit(i.user.id, 'deleteaccount', u.id); return text('Account deleted and unlinked.');
}, { danger: (i) => `Delete the panel account of <@${i.options.getUser('user').id}>?` });
cmd('quota', 'Set a user\'s limits (max servers / default RAM)', 'owner', [usr('user', 'Discord user'), int('servers', 'max servers', false, { min: 0, max: 100 }), int('memory', 'default RAM MB for new servers', false, { min: 128 })], async (i) => {
  const u = i.options.getUser('user'); const q = (db.quotas[u.id] ||= {});
  if (i.options.getInteger('servers') != null) q.servers = i.options.getInteger('servers'); if (i.options.getInteger('memory') != null) q.memory = i.options.getInteger('memory');
  save(); audit(i.user.id, 'quota', `${u.id} ${JSON.stringify(q)}`); return text(`Quota for <@${u.id}>: ${q.servers ?? DEF.maxServers} servers${q.memory ? ` · ${q.memory} MB default RAM` : ''}.`);
});
cmd('maintenance', 'Lock all bot commands for non-owners', 'owner', [str('state', 'on or off', true, { choices: ['on', 'off'] })], async (i) => { db.maintenance = i.options.getString('state') === 'on'; save(); audit(i.user.id, 'maintenance', db.maintenance); return text(`Maintenance mode ${db.maintenance ? '🔒 ON' : '🔓 OFF'}.`); });
cmd('audit', 'Recent bot actions', 'owner', [int('count', 'how many (default 15)', false, { min: 1, max: 40 })], async (i) => {
  const a = db.audit.slice(-(i.options.getInteger('count') || 15)).reverse();
  return emb('Audit log', lines(a.map((x) => `<t:${Math.floor(x.t / 1000)}:R> <@${x.by}> **${x.action}** ${x.detail}`)) || 'empty');
});
cmd('help', 'List all commands', 'user', [], async (i) => {
  const e = new EmbedBuilder().setTitle(`Server Creator — ${defs.length} commands`).setColor(0x5865f2);
  e.addFields({ name: '👤 Everyone', value: clip(defs.filter((d) => d.scope === 'user').map((d) => `\`/${d.name}\``).join(' '), 1000) });
  if (isOwner(i.user.id)) e.addFields({ name: '👑 Owner', value: clip(defs.filter((d) => d.scope === 'owner').map((d) => `\`/${d.name}\``).join(' '), 1000) });
  return { embeds: [e] };
});

// ───────────────────────────── build / register ─────────────────────────────
function build(def) {
  const b = new SlashCommandBuilder().setName(def.name).setDescription(`${def.scope === 'owner' ? '👑 ' : ''}${def.desc}`.slice(0, 100));
  for (const o of def.options) {
    const fill = (x) => {
      x.setName(o.name).setDescription(o.desc.slice(0, 100)).setRequired(!!o.required);
      if (o.choices) x.addChoices(...o.choices.map((c) => ({ name: c, value: c }))); else if (o.auto && x.setAutocomplete) x.setAutocomplete(true);
      if (o.min != null && x.setMinValue) x.setMinValue(o.min); if (o.max != null && x.setMaxValue) x.setMaxValue(o.max); return x;
    };
    ({ string: () => b.addStringOption(fill), integer: () => b.addIntegerOption(fill), boolean: () => b.addBooleanOption(fill), user: () => b.addUserOption(fill) })[o.type]();
  }
  return b.toJSON();
}
const byName = new Map(defs.map((d) => [d.name, d]));
if (COUNT_ONLY) { console.log(`commands: ${defs.map(build).length} (owner ${defs.filter((d) => d.scope === 'owner').length}, user ${defs.filter((d) => d.scope === 'user').length})`); process.exit(0); }
if (defs.length > 98) { console.error(`Too many commands (${defs.length} > 98)`); process.exit(1); }
async function register() {
  const rest = new REST({ version: '10' }).setToken(E.DISCORD_TOKEN);
  const route = E.GUILD_ID ? Routes.applicationGuildCommands(E.CLIENT_ID, E.GUILD_ID) : Routes.applicationCommands(E.CLIENT_ID);
  await rest.put(route, { body: defs.map(build) }); console.log(`Registered ${defs.length} commands ${E.GUILD_ID ? '(guild)' : '(global)'}`);
}
if (process.argv.includes('--register-only')) { register().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); }); return; }

// ───────────────────────────── runtime ─────────────────────────────
const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const EPH = MessageFlags.Ephemeral;
const fail = (i, e) => { console.error(e); const m = { content: `❌ ${clip(e.message || e, 500)}`, embeds: [], components: [] }; return (i.deferred || i.replied) ? i.editReply(m).catch(() => {}) : i.reply({ ...m, flags: EPH }).catch(() => {}); };

async function askConfirm(i, msgText) {
  const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('yes').setLabel('Confirm').setStyle(ButtonStyle.Danger), new ButtonBuilder().setCustomId('no').setLabel('Cancel').setStyle(ButtonStyle.Secondary));
  const msg = await i.editReply({ content: msgText, components: [row] });
  try {
    const c = await msg.awaitMessageComponent({ filter: (x) => x.user.id === i.user.id, time: 30000 });
    if (c.customId !== 'yes') { await c.update({ content: 'Cancelled.', components: [] }); return false; }
    await c.update({ content: '⏳ Working…', components: [] }); return true;
  } catch { await i.editReply({ content: 'Timed out — cancelled.', components: [] }); return false; }
}

async function handleAutocomplete(i) {
  const f = i.options.getFocused(true); const q = String(f.value || '').toLowerCase();
  if (f.name === 'egg') { const eggs = await cachedEggs(); return i.respond(eggs.filter((e) => `${e.nestName} ${e.name}`.toLowerCase().includes(q)).slice(0, 25).map((e) => ({ name: clip(`${e.nestName} — ${e.name}`, 100), value: `${e.nest}:${e.id}` }))); }
  if (f.name === 'server') {
    const list = isOwner(i.user.id) ? await cachedServers() : await serversFor(i.user.id);
    return i.respond(list.filter((s) => `${s.name} ${s.identifier}`.toLowerCase().includes(q)).slice(0, 25).map((s) => ({ name: clip(`${s.name} (${s.identifier})`, 100), value: s.identifier })));
  }
  return i.respond([]);
}

async function handleButton(i) {
  const [, action, ident] = i.customId.split('|');
  const srv = await getServer(ident); assertAccess(i, srv);
  if (db.maintenance && !isOwner(i.user.id)) throw new Error('Maintenance mode is on.');
  if (action === 'console') {
    return i.showModal(new ModalBuilder().setCustomId(`mgm|${ident}`).setTitle(clip(`Command → ${srv.name}`, 45)).addComponents(
      new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('cmd').setLabel('Console command').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(200))));
  }
  if (action === 'backup') { await i.deferReply({ flags: EPH }); const j = await cli('POST', `/servers/${ident}/backups`, {}); audit(i.user.id, 'backup-create', ident); return i.editReply(`💾 Backup **${j.attributes.name}** started.`); }
  if (action === 'address') { await i.deferReply({ flags: EPH }); const j = await cli('GET', `/servers/${ident}`); return i.editReply(j.attributes.relationships.allocations.data.map((d) => `\`${hostPort(d.attributes.ip_alias || d.attributes.ip, d.attributes.port)}\``).join('\n') || 'no allocations'); }
  await i.deferUpdate();
  if (['start', 'stop', 'restart', 'kill'].includes(action)) { if (srv.suspended) throw new Error('This server is suspended.'); await power(srv, action); audit(i.user.id, action, ident); await new Promise((r) => setTimeout(r, 1500)); }
  return i.editReply(await managePayload(srv));
}

client.on('interactionCreate', async (i) => {
  try {
    if (i.isAutocomplete()) return await handleAutocomplete(i);
    if (db.maintenance && !isOwner(i.user.id) && !i.isAutocomplete()) return i.reply({ content: '🔧 The bot is in maintenance mode.', flags: EPH });
    if (i.isButton() && i.customId.startsWith('mg|')) return await handleButton(i);
    if (i.isStringSelectMenu() && i.customId === 'mgsel') { await i.deferReply({ flags: EPH }); const srv = await getServer(i.values[0]); assertAccess(i, srv); return i.editReply(await managePayload(srv)); }
    if (i.isModalSubmit() && i.customId.startsWith('mgm|')) {
      await i.deferReply({ flags: EPH }); const ident = i.customId.split('|')[1]; const srv = await getServer(ident); assertAccess(i, srv);
      const c = i.fields.getTextInputValue('cmd'); await cli('POST', `/servers/${ident}/command`, { command: c }); audit(i.user.id, 'console', `${ident}: ${c}`); return i.editReply(`Sent \`${clip(c, 200)}\` to **${srv.name}**.`);
    }
    if (!i.isChatInputCommand()) return;
    const def = byName.get(i.commandName); if (!def) return;
    if (def.scope === 'owner' && !isOwner(i.user.id)) return i.reply({ content: '⛔ Owner only.', flags: EPH });
    await i.deferReply({ flags: EPH });
    if (def.danger && !(await askConfirm(i, def.danger(i)))) return;
    const res = await def.run(i);
    await i.editReply({ content: '', embeds: [], components: [], ...res });
  } catch (e) { fail(i, e); }
});

client.once(Events.ClientReady, async () => {
  console.log(`Logged in as ${client.user.tag} — ${defs.length} commands`);
  try { await register(); } catch (e) { console.error('register failed:', e.message); }
  client.user.setPresence({ activities: [{ name: '/manage — your servers' }], status: 'online' });
});
process.on('unhandledRejection', (e) => console.error('unhandled:', e));
process.on('SIGTERM', () => { try { fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2)); } catch { /* ignore */ } process.exit(0); });
client.login(E.DISCORD_TOKEN);
