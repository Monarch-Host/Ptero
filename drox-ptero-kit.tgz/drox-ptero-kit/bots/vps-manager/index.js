'use strict';
/**
 * Drox VPS Manager — owner-only Discord bot for managing a Pterodactyl VPS.
 * 80+ slash commands: system, services, panel, wings, nginx, db, docker, tunnel, backups.
 */
require('dotenv').config();
const fs = require('fs');
const os = require('os');
const path = require('path');
const { exec } = require('child_process');
const {
  Client, Events, GatewayIntentBits, REST, Routes, SlashCommandBuilder, EmbedBuilder,
  ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder, MessageFlags,
} = require('discord.js');

// ───────────────────────────── config ─────────────────────────────
const OWNERS = (process.env.OWNER_IDS || '').split(',').map((s) => s.trim()).filter(Boolean);
const PANEL_DIR = process.env.PANEL_DIR || '/var/www/pterodactyl';
const BACKUP_DIR = process.env.BACKUP_DIR || '/var/backups/drox';
const ALLOW_EXEC = String(process.env.ALLOW_EXEC).toLowerCase() === 'true';
const MONITOR_SEC = Math.max(15, parseInt(process.env.MONITOR_INTERVAL_SEC || '60', 10));
if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) { console.error('Set DISCORD_TOKEN and CLIENT_ID in .env'); process.exit(1); }
if (!OWNERS.length) { console.error('Set OWNER_IDS in .env'); process.exit(1); }

// ───────────────────────────── helpers ─────────────────────────────
const ANSI = /\x1b\[[0-9;]*[A-Za-z]/g;
const SAFE_UNIT = /^[A-Za-z0-9@._:-]{1,64}$/;
const SAFE_HOST = /^[A-Za-z0-9.:-]{1,253}$/;
const SAFE_FILE = /^(latest|[A-Za-z0-9._-]{1,160})$/;
const SAFE_LABEL = /^[A-Za-z0-9_-]{1,24}$/;

const sh = (cmd, timeout = 60000) => new Promise((resolve) => {
  exec(cmd, { timeout, maxBuffer: 20 * 1024 * 1024, shell: '/bin/bash', env: { ...process.env, TERM: 'dumb', COMPOSER_ALLOW_SUPERUSER: '1' } },
    (err, so, se) => {
      let t = `${so || ''}${se || ''}`.replace(ANSI, '').trim();
      if (!t) t = err ? `error: ${err.message}` : '(no output)';
      else if (err && err.killed) t += '\n[timed out]';
      resolve(t);
    });
});
const must = (v, re, what) => { if (!re.test(v || '')) throw new Error(`invalid ${what}`); return v; };
const clip = (s, n = 1000) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);
const fmtBytes = (b) => { const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; while (b >= 1024 && i < 4) { b /= 1024; i++; } return `${b.toFixed(1)} ${u[i]}`; };
const fmtUptime = (s) => { const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return `${d}d ${h}h ${m}m`; };

let PHP_FPM = 'php8.3-fpm';
(async () => {
  const u = await sh("systemctl list-unit-files 'php*-fpm.service' --no-legend | awk '{print $1}' | head -1 | sed 's/.service//'");
  if (/^php[\d.]+-fpm$/.test(u)) PHP_FPM = u;
})();
const WATCHED = () => ['nginx', PHP_FPM, 'mariadb', 'redis-server', 'docker', 'wings', 'pteroq', 'cloudflared', 'fail2ban'];
const KNOWN_UNITS = () => [...WATCHED(), 'drox-backup.timer', 'drox-backup.service', 'drox-vps-manager', 'drox-server-creator', 'cron', 'ssh', 'ufw', 'systemd-resolved'];

// ───────────────────────────── command registry ─────────────────────────────
const defs = [];
const str = (name, desc, required = true, extra = {}) => ({ type: 'string', name, desc, required, ...extra });
const int = (name, desc, required = false, extra = {}) => ({ type: 'integer', name, desc, required, ...extra });
const bool = (name, desc, required = false) => ({ type: 'boolean', name, desc, required });
const svcOpt = () => str('service', 'systemd unit, e.g. nginx / wings', true, { auto: true });

/** cmd(name, desc, options, run, {danger}) — run(i) returns string | {text, file} */
function cmd(name, desc, options, run, meta = {}) { defs.push({ name, desc, options: options || [], run, ...meta }); }
/** shell shortcut: simple read-only command */
function info(name, desc, script, options) { cmd(name, desc, options, async () => sh(script)); }

const artisan = (a) => `cd ${PANEL_DIR} && php artisan ${a}`;
const unitOf = (i) => must(i.options.getString('service'), SAFE_UNIT, 'service name');
const linesOf = (i, d = 40) => Math.min(Math.max(i.options.getInteger('lines') || d, 1), 300);
const linesOpt = () => int('lines', 'how many lines (default 40)', false, { min: 1, max: 300 });

// ═════════════════ SYSTEM (read-only) ═════════════════
info('uptime', 'Server uptime', 'uptime -p; uptime -s; uptime');
info('cpu', 'CPU info and top consumers', "lscpu | grep -E 'Model name|^CPU\\(s\\)|MHz|Thread|Core'; echo; ps -eo pid,comm,%cpu --sort=-%cpu | head -8");
info('memory', 'RAM and swap usage', 'free -h');
info('disk', 'Disk usage', 'df -hT -x tmpfs -x devtmpfs -x overlay');
info('inodes', 'Inode usage', 'df -i -x tmpfs -x devtmpfs -x overlay');
info('network', 'Interfaces and IPv6 routes', 'ip -br addr; echo; ip -6 route | head -10');
info('ip', 'Public IPv6 (and IPv4 if the VPS has one)', "ip -6 addr show scope global | grep inet6; echo; curl -6 -s --max-time 6 https://ifconfig.co || echo 'no v6 egress'; echo; curl -4 -s --max-time 4 https://ifconfig.co || echo 'no IPv4 (NAT64 only)'");
info('load', 'Load average', 'cat /proc/loadavg');
info('processes', 'Top processes by CPU', 'ps aux --sort=-%cpu | head -16');
info('top-mem', 'Top processes by memory', 'ps aux --sort=-%mem | head -16');
info('hostname', 'Host details', 'hostnamectl');
info('os', 'OS release', 'cat /etc/os-release');
info('kernel', 'Kernel version', 'uname -a');
info('ports', 'Listening ports', 'ss -tulpn');
info('connections', 'Socket summary', 'ss -s');
info('logins', 'Recent logins', 'last -n 15');
info('who', 'Logged-in users', 'w');
info('time', 'Time and timezone', 'timedatectl');
info('swap', 'Swap devices', 'swapon --show; free -h | grep -i swap');
info('block', 'Block devices', 'lsblk');
info('dmesg', 'Kernel log tail', 'dmesg -T | tail -30');
info('nat64-check', 'Test DNS64/NAT64 reachability of IPv4-only hosts', "for h in github.com registry-1.docker.io deb.nodesource.com; do printf '%-26s' $h; getent ahostsv6 $h | head -1 | awk '{print $1}'; done; curl -s -o /dev/null -w 'github http=%{http_code}\\n' --max-time 8 https://github.com");
info('cron-list', 'Root crontab', 'crontab -l 2>&1');
info('timers', 'Systemd timers', 'systemctl list-timers --no-pager | head -20');
info('firewall', 'UFW status', 'ufw status verbose');
info('fail2ban', 'fail2ban status', 'fail2ban-client status; fail2ban-client status sshd 2>&1');
info('services', 'Running services', 'systemctl list-units --type=service --state=running --no-pager | head -40');
info('failed', 'Failed units', 'systemctl --failed --no-pager');
cmd('ping', 'Ping a host', [str('host', 'hostname or IP')], async (i) => sh(`ping -c 4 -W 3 -- "${must(i.options.getString('host'), SAFE_HOST, 'host')}"`));
cmd('dns', 'Resolve a hostname (A/AAAA incl. DNS64)', [str('host', 'hostname')], async (i) => sh(`getent ahosts "${must(i.options.getString('host'), SAFE_HOST, 'host')}"`));
cmd('journal', 'System journal tail', [linesOpt()], async (i) => sh(`journalctl -n ${linesOf(i)} --no-pager`));

// ═════════════════ SERVICES ═════════════════
cmd('svc-status', 'Status of a systemd unit', [svcOpt()], async (i) => sh(`systemctl status "${unitOf(i)}" --no-pager -l | head -25`));
cmd('svc-start', 'Start a unit', [svcOpt()], async (i) => { const u = unitOf(i); return sh(`systemctl start "${u}"; systemctl is-active "${u}"`); });
cmd('svc-stop', 'Stop a unit', [svcOpt()], async (i) => { const u = unitOf(i); return sh(`systemctl stop "${u}"; systemctl is-active "${u}"`); }, { danger: (i) => `Stop \`${i.options.getString('service')}\`?` });
cmd('svc-restart', 'Restart a unit', [svcOpt()], async (i) => { const u = unitOf(i); return sh(`systemctl restart "${u}"; systemctl is-active "${u}"`); });
cmd('svc-enable', 'Enable a unit at boot', [svcOpt()], async (i) => sh(`systemctl enable "${unitOf(i)}" 2>&1`));
cmd('svc-disable', 'Disable a unit at boot', [svcOpt()], async (i) => sh(`systemctl disable "${unitOf(i)}" 2>&1`));
cmd('svc-logs', 'Journal for one unit', [svcOpt(), linesOpt()], async (i) => sh(`journalctl -u "${unitOf(i)}" -n ${linesOf(i)} --no-pager`));

// ═════════════════ PANEL ═════════════════
cmd('panel-status', 'Health of every panel component', [], async () => {
  const rows = [];
  for (const s of WATCHED()) rows.push(`${(await sh(`systemctl is-active ${s}`)).split('\n')[0].padEnd(10)} ${s}`);
  const code = await sh(`curl -s -o /dev/null -w '%{http_code}' --max-time 6 http://127.0.0.1/auth/login -H 'Host: localhost'`);
  return `${rows.join('\n')}\n\nlocal panel HTTP: ${code}`;
});
cmd('panel-restart', 'Restart nginx + php-fpm + queue worker', [], async () => sh(`systemctl restart nginx ${PHP_FPM} pteroq; systemctl is-active nginx ${PHP_FPM} pteroq`));
cmd('panel-queue-restart', 'Restart the queue worker', [], async () => sh(`${artisan('queue:restart')}; systemctl restart pteroq; systemctl is-active pteroq`));
cmd('panel-cache-clear', 'Clear view/config/app cache', [], async () => sh(`${artisan('view:clear')} && ${artisan('config:clear')} && ${artisan('cache:clear')}`));
cmd('panel-down', 'Put the panel in maintenance mode', [], async () => sh(artisan('down')));
cmd('panel-up', 'Bring the panel out of maintenance mode', [], async () => sh(artisan('up')));
cmd('panel-info', 'Panel version and environment', [], async () => sh(artisan('p:info')));
cmd('panel-logs', 'Tail the panel (Laravel) log', [linesOpt()], async (i) => sh(`f=$(ls -1t ${PANEL_DIR}/storage/logs/laravel-*.log 2>/dev/null | head -1); [ -n "$f" ] && tail -n ${linesOf(i)} "$f" || echo 'no log yet'`));
cmd('panel-update', 'Update the panel to the latest release (auto-backup first)', [], async () => sh([
  'set -e', 'drox-backup backup pre-update', `cd ${PANEL_DIR}`, 'php artisan down',
  'curl -fsSL https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz | tar -xz',
  'chmod -R 755 storage/* bootstrap/cache', 'composer install --no-dev --optimize-autoloader --no-interaction 2>&1 | tail -3',
  'php artisan view:clear', 'php artisan config:clear', 'php artisan migrate --seed --force',
  `chown -R www-data:www-data ${PANEL_DIR}`, 'php artisan queue:restart', 'php artisan up', 'systemctl restart pteroq', 'php artisan --version',
].join(' && '), 600000), { danger: () => 'Update the panel now? A backup is taken first and the panel goes into maintenance mode briefly.' });

// ═════════════════ WINGS ═════════════════
cmd('wings-status', 'Wings daemon status', [], async () => sh('systemctl status wings --no-pager -l | head -20'));
cmd('wings-restart', 'Restart Wings (game servers keep running)', [], async () => sh('systemctl restart wings; sleep 2; systemctl is-active wings'));
cmd('wings-logs', 'Wings log tail', [linesOpt()], async (i) => sh(`journalctl -u wings -n ${linesOf(i)} --no-pager`));
cmd('wings-version', 'Installed Wings version', [], async () => sh('wings --version'));
cmd('wings-update', 'Update Wings to the latest release', [], async () => sh([
  'set -e', 'A=$(uname -m); [ "$A" = x86_64 ] && A=amd64 || A=arm64',
  'curl -fsSL -o /tmp/wings.new "https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_$A"',
  'chmod +x /tmp/wings.new', 'systemctl stop wings', 'mv /tmp/wings.new /usr/local/bin/wings', 'systemctl start wings', 'wings --version',
].join(' && '), 180000), { danger: () => 'Update Wings and restart the daemon?' });

// ═════════════════ NGINX / DB / REDIS ═════════════════
info('nginx-test', 'Validate nginx config', 'nginx -t 2>&1');
info('nginx-reload', 'Reload nginx', 'nginx -t 2>&1 && systemctl reload nginx && echo reloaded');
cmd('nginx-errors', 'nginx error log tail', [linesOpt()], async (i) => sh(`tail -n ${linesOf(i, 30)} /var/log/nginx/error.log; echo ---; tail -n ${linesOf(i, 30)} /var/log/nginx/pterodactyl.app-error.log 2>/dev/null`));
info('db-status', 'MariaDB status and connections', 'mariadb -e "status; show global status like \'Threads_connected\'; show global status like \'Uptime\';" 2>&1');
info('db-size', 'Database sizes', 'mariadb -e "select table_schema db, round(sum(data_length+index_length)/1024/1024,2) mb from information_schema.tables group by table_schema order by mb desc;" 2>&1');
info('redis-ping', 'Redis health', 'redis-cli ping; redis-cli info memory | grep -E "used_memory_human|maxmemory_human"; redis-cli info clients | grep connected_clients');

// ═════════════════ DOCKER ═════════════════
info('docker-ps', 'Running containers', "docker ps --format 'table {{.Names}}\\t{{.Status}}\\t{{.Image}}' | head -40");
info('docker-stats', 'Container CPU/RAM snapshot', "docker stats --no-stream --format 'table {{.Name}}\\t{{.CPUPerc}}\\t{{.MemUsage}}' | head -40");
info('docker-images', 'Docker images', 'docker images');
info('docker-df', 'Docker disk usage', 'docker system df');
cmd('docker-prune', 'Remove unused Docker images (keeps containers/volumes)', [], async () => sh('docker image prune -af 2>&1 | tail -5'), { danger: () => 'Remove all unused Docker images?' });
cmd('docker-restart', 'Restart the Docker daemon (stops game servers!)', [], async () => sh('systemctl restart docker; sleep 3; systemctl is-active docker wings'), { danger: () => '⚠️ Restarting Docker will stop every game server. Continue?' });

// ═════════════════ CLOUDFLARE TUNNEL ═════════════════
info('tunnel-status', 'cloudflared status', 'systemctl status cloudflared --no-pager -l | head -15');
info('tunnel-restart', 'Restart cloudflared', 'systemctl restart cloudflared; sleep 2; systemctl is-active cloudflared');
cmd('tunnel-logs', 'cloudflared log tail', [linesOpt()], async (i) => sh(`journalctl -u cloudflared -n ${linesOf(i, 30)} --no-pager`));

// ═════════════════ BACKUPS ═════════════════
const fileOf = (i) => must(i.options.getString('file'), SAFE_FILE, 'backup file name');
const fileOpt = (d = 'backup file name, or "latest"') => str('file', d, true);
cmd('backup-now', 'Back up the whole site right now (DB + panel + configs + bots)', [str('label', 'optional label', false)], async (i) => {
  const l = i.options.getString('label'); const label = l ? must(l, SAFE_LABEL, 'label') : 'manual';
  const o = await sh(`drox-backup backup ${label}`, 600000);
  return `${o}\n\n${await sh('drox-backup list | head -5')}`;
});
cmd('backup-list', 'List backups', [], async () => sh('drox-backup list | head -40'));
cmd('backup-latest', 'Show the newest backup and its age', [], async () => sh(`f=$(drox-backup latest); [ -n "$f" ] && { ls -lh "$f"; echo "age: $(( ($(date +%s)-$(stat -c %Y "$f"))/60 )) min"; } || echo 'no backups yet'`));
cmd('backup-verify', 'Verify a backup archive + checksum', [fileOpt()], async (i) => sh(`drox-backup verify "${fileOf(i)}" 2>&1`, 300000));
cmd('backup-send', 'Upload a backup here (≤9MB; contains secrets — ephemeral reply)', [fileOpt()], async (i) => {
  const p = (await sh(`drox-backup send "${fileOf(i)}" 2>&1`)).split('\n').pop();
  if (!p.startsWith('/') || !fs.existsSync(p)) return p;
  const size = fs.statSync(p).size;
  if (size > 9.5 * 1024 * 1024) return `Too large for Discord (${fmtBytes(size)}).\nCopy it with:  scp root@<vps>:${p} .`;
  return { text: `${path.basename(p)} (${fmtBytes(size)})`, file: p };
});
cmd('backup-restore', 'RESTORE the site from a backup (takes a safety backup first)', [fileOpt()], async (i) => sh(`drox-backup restore "${fileOf(i)}" 2>&1`, 900000),
  { danger: (i) => `⚠️ Restore **${i.options.getString('file')}**? Panel, configs and database will be overwritten (a pre-restore backup is taken first).` });
cmd('backup-delete', 'Delete one backup', [fileOpt('backup file name')], async (i) => { const f = fileOf(i); if (f === 'latest') throw new Error('give an exact file name'); return sh(`rm -v -- "${BACKUP_DIR}/${f}" "${BACKUP_DIR}/${f}.sha256" 2>&1`); }, { danger: (i) => `Delete backup **${i.options.getString('file')}**?` });
cmd('backup-prune', 'Apply retention policy now', [], async () => sh('drox-backup prune 2>&1'));
cmd('backup-timer', 'Auto-backup timer status (every 10 min)', [], async () => sh('drox-backup timer status'));
cmd('backup-auto', 'Turn the 10-minute auto-backup on/off', [str('state', 'on or off', true, { choices: ['on', 'off'] })], async (i) => sh(`drox-backup timer ${i.options.getString('state') === 'on' ? 'on' : 'off'}`));
cmd('backup-space', 'Backup folder size and free disk', [], async () => sh(`du -sh ${BACKUP_DIR}; ls ${BACKUP_DIR}/drox-*.tar.* 2>/dev/null | grep -vc sha256; df -h ${BACKUP_DIR} | tail -1`));
cmd('backup-log', 'Recent auto-backup runs', [linesOpt()], async (i) => sh(`journalctl -u drox-backup -n ${linesOf(i, 30)} --no-pager`));
cmd('backup-volumes', 'Include game-server data (volumes) in backups?', [str('state', 'on or off', true, { choices: ['on', 'off'] })], async (i) => {
  const v = i.options.getString('state') === 'on' ? 1 : 0;
  return sh(`sed -i 's/^INCLUDE_VOLUMES=.*/INCLUDE_VOLUMES=${v}/' /etc/drox/backup.env; grep INCLUDE_VOLUMES /etc/drox/backup.env`) + (v ? '\n⚠️ Volumes can be huge — watch backup-space.' : '');
});

// ═════════════════ SYSTEM ACTIONS ═════════════════
cmd('update-system', 'apt update + upgrade', [], async () => sh('apt-get update -y >/dev/null 2>&1; DEBIAN_FRONTEND=noninteractive apt-get -y upgrade 2>&1 | tail -15', 900000), { danger: () => 'Run apt upgrade now?' });
cmd('apt-cleanup', 'apt autoremove + clean', [], async () => sh('apt-get -y autoremove 2>&1 | tail -3; apt-get clean; df -h / | tail -1'));
cmd('reboot', 'Reboot the VPS', [], async () => { setTimeout(() => exec('systemctl reboot'), 1500); return 'Rebooting in 2s… the bot will come back by itself.'; }, { danger: () => '⚠️ Reboot the whole VPS?' });
cmd('shutdown', 'Power off the VPS', [], async () => { setTimeout(() => exec('systemctl poweroff'), 1500); return 'Powering off. You will need your provider panel to turn it back on.'; }, { danger: () => '⚠️ POWER OFF the VPS? You will need your provider to turn it back on.' });
cmd('kill', 'Send SIGTERM to a process', [int('pid', 'process id', true, { min: 2 })], async (i) => sh(`kill -15 ${parseInt(i.options.getInteger('pid'), 10)} 2>&1 && echo sent`), { danger: (i) => `Kill PID ${i.options.getInteger('pid')}?` });
cmd('exec', 'Run a shell command as root (needs ALLOW_EXEC=true)', [str('command', 'shell command')], async (i) => {
  if (!ALLOW_EXEC) throw new Error('exec is disabled — set ALLOW_EXEC=true in .env and restart the bot');
  return sh(i.options.getString('command'), 120000);
}, { danger: (i) => `Run as root:\n\`${clip(i.options.getString('command'), 300)}\`` });

// ═════════════════ STATUS / HELP ═════════════════
cmd('status', 'One-glance server dashboard', [], async () => {
  const [disk, active] = await Promise.all([
    sh("df -h / | tail -1 | awk '{print $3\" / \"$2\" (\"$5\")\"}'"),
    Promise.all(WATCHED().map(async (s) => [s, (await sh(`systemctl is-active ${s}`)).split('\n')[0]])),
  ]);
  const last = await sh('f=$(drox-backup latest); [ -n "$f" ] && echo $(( ($(date +%s)-$(stat -c %Y "$f"))/60 )) || echo -1');
  const total = os.totalmem(), used = total - os.freemem();
  const e = new EmbedBuilder().setTitle(`🖥️ ${os.hostname()}`).setColor(active.every(([, a]) => a === 'active') ? 0x2ecc71 : 0xe74c3c)
    .addFields(
      { name: 'Uptime', value: fmtUptime(os.uptime()), inline: true },
      { name: 'Load', value: os.loadavg().map((n) => n.toFixed(2)).join(' · '), inline: true },
      { name: 'CPUs', value: String(os.cpus().length), inline: true },
      { name: 'RAM', value: `${fmtBytes(used)} / ${fmtBytes(total)}`, inline: true },
      { name: 'Disk /', value: disk, inline: true },
      { name: 'Last backup', value: Number(last) < 0 ? 'none!' : `${last} min ago`, inline: true },
      { name: 'Services', value: active.map(([s, a]) => `${a === 'active' ? '🟢' : '🔴'} ${s}`).join('\n') },
    ).setTimestamp();
  return { embed: e };
});
cmd('help', 'List all commands', [], async () => {
  const groups = {
    System: ['uptime', 'cpu', 'memory', 'disk', 'inodes', 'network', 'ip', 'load', 'processes', 'top-mem', 'hostname', 'os', 'kernel', 'ports', 'connections', 'logins', 'who', 'time', 'swap', 'block', 'dmesg', 'nat64-check', 'cron-list', 'timers', 'firewall', 'fail2ban', 'ping', 'dns', 'journal'],
    Services: ['services', 'failed', 'svc-status', 'svc-start', 'svc-stop', 'svc-restart', 'svc-enable', 'svc-disable', 'svc-logs'],
    Panel: ['panel-status', 'panel-restart', 'panel-queue-restart', 'panel-cache-clear', 'panel-down', 'panel-up', 'panel-info', 'panel-logs', 'panel-update'],
    Wings: ['wings-status', 'wings-restart', 'wings-logs', 'wings-version', 'wings-update'],
    'Web / DB': ['nginx-test', 'nginx-reload', 'nginx-errors', 'db-status', 'db-size', 'redis-ping'],
    'Docker / Tunnel': ['docker-ps', 'docker-stats', 'docker-images', 'docker-df', 'docker-prune', 'docker-restart', 'tunnel-status', 'tunnel-restart', 'tunnel-logs'],
    Backups: ['backup-now', 'backup-list', 'backup-latest', 'backup-verify', 'backup-send', 'backup-restore', 'backup-delete', 'backup-prune', 'backup-timer', 'backup-auto', 'backup-space', 'backup-log', 'backup-volumes'],
    Actions: ['update-system', 'apt-cleanup', 'reboot', 'shutdown', 'kill', 'exec', 'status', 'help'],
  };
  const e = new EmbedBuilder().setTitle(`VPS Manager — ${defs.length} commands`).setColor(0x5865f2)
    .setDescription('Owner-only. ⚠️ commands ask for confirmation.');
  for (const [g, list] of Object.entries(groups)) e.addFields({ name: g, value: list.map((n) => `\`/${n}\``).join(' ') });
  return { embed: e };
});

// ───────────────────────────── build + register ─────────────────────────────
function build(def) {
  const b = new SlashCommandBuilder().setName(def.name).setDescription(def.desc.slice(0, 100));
  for (const o of def.options) {
    const fill = (x) => {
      x.setName(o.name).setDescription(o.desc.slice(0, 100)).setRequired(!!o.required);
      if (o.choices) x.addChoices(...o.choices.map((c) => ({ name: c, value: c })));
      else if (o.auto && x.setAutocomplete) x.setAutocomplete(true);
      if (o.min != null && x.setMinValue) x.setMinValue(o.min);
      if (o.max != null && x.setMaxValue) x.setMaxValue(o.max);
      return x;
    };
    if (o.type === 'string') b.addStringOption(fill);
    else if (o.type === 'integer') b.addIntegerOption(fill);
    else if (o.type === 'boolean') b.addBooleanOption(fill);
  }
  return b.toJSON();
}
const byName = new Map(defs.map((d) => [d.name, d]));
if (process.argv.includes('--count')) { const built = defs.map(build); console.log(`commands: ${built.length}`); process.exit(0); }
if (defs.length > 98) { console.error(`Too many commands (${defs.length} > 98)`); process.exit(1); }

async function register() {
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
  const body = defs.map(build);
  const route = process.env.GUILD_ID ? Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID) : Routes.applicationCommands(process.env.CLIENT_ID);
  await rest.put(route, { body });
  console.log(`Registered ${body.length} commands ${process.env.GUILD_ID ? '(guild)' : '(global)'}`);
}
if (process.argv.includes('--register-only')) { register().then(() => process.exit(0)).catch((e) => { console.error(e); process.exit(1); }); return; }

// ───────────────────────────── runtime ─────────────────────────────
const client = new Client({ intents: [GatewayIntentBits.Guilds] });

async function sendResult(i, title, res) {
  if (res && res.embed) return i.editReply({ content: '', embeds: [res.embed], components: [] });
  if (res && res.file) return i.editReply({ content: `📎 ${res.text}`, files: [new AttachmentBuilder(res.file)], components: [] });
  const text = String(res);
  if (text.length <= 1900) return i.editReply({ content: `**/${title}**\n\`\`\`\n${text}\n\`\`\``, components: [] });
  return i.editReply({ content: `**/${title}** — output attached (${text.length} chars)`, files: [new AttachmentBuilder(Buffer.from(text), { name: `${title}.txt` })], components: [] });
}

async function askConfirm(i, text) {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('yes').setLabel('Confirm').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('no').setLabel('Cancel').setStyle(ButtonStyle.Secondary));
  const msg = await i.editReply({ content: text, components: [row] });
  try {
    const c = await msg.awaitMessageComponent({ filter: (x) => x.user.id === i.user.id, time: 30000 });
    if (c.customId !== 'yes') { await c.update({ content: 'Cancelled.', components: [] }); return false; }
    await c.update({ content: '⏳ Running…', components: [] });
    return true;
  } catch { await i.editReply({ content: 'Timed out — cancelled.', components: [] }); return false; }
}

client.on('interactionCreate', async (i) => {
  try {
    if (i.isAutocomplete()) {
      const q = String(i.options.getFocused() || '').toLowerCase();
      return i.respond(KNOWN_UNITS().filter((u) => u.toLowerCase().includes(q)).slice(0, 25).map((u) => ({ name: u, value: u })));
    }
    if (!i.isChatInputCommand()) return;
    if (!OWNERS.includes(i.user.id)) return i.reply({ content: '⛔ Owner only.', flags: MessageFlags.Ephemeral });
    const def = byName.get(i.commandName); if (!def) return;
    await i.deferReply({ flags: MessageFlags.Ephemeral });
    if (def.danger && !(await askConfirm(i, def.danger(i)))) return;
    console.log(`[${new Date().toISOString()}] ${i.user.tag} /${def.name}`);
    await sendResult(i, def.name, await def.run(i));
  } catch (e) {
    console.error(e);
    const msg = `❌ ${clip(String(e.message || e), 500)}`;
    if (i.deferred || i.replied) i.editReply({ content: msg, components: [] }).catch(() => {});
    else if (i.reply) i.reply({ content: msg, flags: MessageFlags.Ephemeral }).catch(() => {});
  }
});

// ───────────────────────────── monitor: service down/up + stale backup ─────────────────────────────
const last = new Map(); let backupAlerted = false;
async function alert(text) {
  try {
    if (process.env.ALERT_CHANNEL_ID) { const ch = await client.channels.fetch(process.env.ALERT_CHANNEL_ID); return ch.send(text); }
    const u = await client.users.fetch(OWNERS[0]); return u.send(text);
  } catch (e) { console.error('alert failed:', e.message); }
}
async function monitor() {
  for (const s of WATCHED()) {
    const a = (await sh(`systemctl is-active ${s}`)).split('\n')[0];
    const prev = last.get(s);
    if (prev === undefined) { last.set(s, a); continue; }
    if (a !== prev) { last.set(s, a); await alert(a === 'active' ? `🟢 **${s}** is back up on \`${os.hostname()}\`` : `🔴 **${s}** is **${a}** on \`${os.hostname()}\``); }
  }
  const age = Number(await sh('f=$(drox-backup latest 2>/dev/null); [ -n "$f" ] && echo $(( ($(date +%s)-$(stat -c %Y "$f"))/60 )) || echo -1'));
  if (age > 30 && !backupAlerted) { backupAlerted = true; await alert(`⚠️ Last backup is ${age} min old (auto-backup should run every 10). Check \`/backup-timer\` and \`/backup-log\`.`); }
  if (age >= 0 && age <= 15) backupAlerted = false;
}

client.once(Events.ClientReady, async () => {
  console.log(`Logged in as ${client.user.tag} — ${defs.length} commands`);
  try { await register(); } catch (e) { console.error('register failed:', e.message); }
  client.user.setPresence({ activities: [{ name: `${os.hostname()} | /help` }], status: 'online' });
  setInterval(() => monitor().catch((e) => console.error('monitor:', e.message)), MONITOR_SEC * 1000);
  monitor().catch(() => {});
});
process.on('unhandledRejection', (e) => console.error('unhandled:', e));
client.login(process.env.DISCORD_TOKEN);
